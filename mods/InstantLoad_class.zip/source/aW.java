package com.threerings.projectx.client;

import java.util.Objects;

/**
 * Loading-screen fade animator — shadows the game's own {@code aW}.
 *
 * When a level finishes loading, {@code aV.EH()} creates this as a tick participant to fade the
 * loading screen out over ~5 seconds (fadeBackground 3s + linger 1s + fadeTitle 1s), so the level
 * fades in. With {@code skip_fade=true} (the default) we instead reveal the level INSTANTLY: on the
 * first tick we run the loading-done hook ({@code aV.EI()}) and dismiss the loading window
 * ({@code completed() -> aV.EJ() -> root.dismiss()}), skipping the fade entirely.
 *
 * Purely client-side presentation — the loading screen is a local GUI window; nothing is sent.
 * {@code skip_fade=false} in ~/sk_loading.properties restores the original ~5s fade.
 *
 * Faithful reconstruction: the base class {@code com.threerings.opengl.util.m} reflects the phase
 * method names (fadeBackground/linger/fadeTitle) in its constructor and divides by their durations
 * in its own tick(), so those methods are kept exactly as the original and only {@code tick()}
 * short-circuits. If the instant path ever fails it falls back to the game's normal fade, so the
 * loading screen can never get stuck.
 */
class aW extends com.threerings.opengl.util.m
{
    protected boolean aFx;
    final aV aFy;

    aW(aV var1, Object... var2) {
        super(var2);
        this.aFy = Objects.requireNonNull(var1);
    }

    public void tick(float var1) {
        if (skipFade()) {
            try {
                if (!this.aFx) {
                    this.aFy.EI();          // notify the view that loading is done (enable interaction)
                    this.aFx = true;
                }
                this.completed();           // EJ() dismisses the loading window + restores music + unhooks us
                return;
            } catch (Throwable t) {
                // instant reveal failed for some reason — fall back to the normal fade below so the
                // loading screen still finishes and can never soft-lock
            }
        }
        if (this.aFy.aAG.IH().isAdded()) {
            super.tick(var1);
        } else {
            this.completed();
        }
    }

    // --- phases below are the ORIGINAL behaviour, used only when skip_fade=false (and required to
    //     exist so the base constructor's reflection can find them by name) ---

    protected void fadeBackground() {
        this.aFy.setAlpha(this._cpct);
        this.aFy.aFt.setAlpha(1.0F);
        this.aFy.aFu.setAlpha(1.0F);
        if (this.aFy.aFr != null) {
            this.aFy.aFr.setAlpha(this._cpct);
        }
        this.aFy._ctx.Gu().getStreamGain().value = ProjectXPrefs.Hr() * this._pct;
    }

    protected void linger() {
        if (!this.aFx) {
            this.aFy.EI();
            this.aFx = true;
        }
    }

    protected void fadeTitle() {
        this.aFy.aFt.setAlpha(this._cpct);
        this.aFy.aFu.setAlpha(this._cpct);
    }

    protected void completed() {
        this.aFy.EJ();
        this.aFy._ctx.Gt().removeTickParticipant(this);
        this.aFy._ctx.Gu().getStreamGain().value = ProjectXPrefs.Hr();
    }

    // --- skip_fade setting, read once ---

    static Boolean _skip;

    static boolean skipFade() {
        Boolean s = _skip;
        if (s == null) {
            s = Boolean.TRUE;
            try {
                java.io.File f = new java.io.File(System.getProperty("user.home"), "sk_loading.properties");
                if (f.exists()) {
                    java.util.Properties p = new java.util.Properties();
                    java.io.FileInputStream in = new java.io.FileInputStream(f);
                    p.load(in);
                    in.close();
                    s = Boolean.valueOf(!"false".equalsIgnoreCase(
                        p.getProperty("skip_fade", "true").trim()));
                } else {
                    java.io.PrintWriter w = new java.io.PrintWriter(new java.io.FileWriter(f));
                    w.println("# Spiral Knights loading-screen fade (client-side GUI only)");
                    w.println("# true  = reveal the level instantly when it finishes loading");
                    w.println("# false = original slow ~5s fade-in");
                    w.println("skip_fade=true");
                    w.close();
                }
            } catch (Throwable t) {
                // default: skip the fade
            }
            _skip = s;
        }
        return s.booleanValue();
    }
}
