Really Visible Harvester

Mod made by Glowbomb12

To install:
- Without KnightLauncher ----->   Drop "character" and "particle" folders in "Spiral Knights/rsrc"
- With KnightLauncher ----->  Drop this entire zip into "Spiral Knights/mods"

NOTE: Any swapping you do with this mod MUST be made here in the zip file if you plan to "clean" frequently, as these changes will be more permanent than just changing in the game's folders.


Changes & Features:
- The Apocrean Harvester has a bright aura around it for better visibility and a giant arrow to show its current direction.
- Orange ring means you are close but harvester can only follow you.
- Red ring means that you are too close and you run the high risk of being attacked.



Note: 
Strangely enough, harvester unrenders if you are too far "above" it 
(about 1/4 past red ring if harvester is at bottom center of screen) 
and re-renders when the distance is closed, but mostly should continue following you.