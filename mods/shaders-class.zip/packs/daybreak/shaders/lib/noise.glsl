//
// Value noise, and the sum of a few octaves of it.
//
// Not gradient (Perlin) noise, which would be the textbook choice: gradient noise needs a
// pseudo-random VECTOR per lattice point and a dot product per corner, and at four octaves
// over a full-screen pass that is four times the arithmetic for a difference nobody can see
// through a cloud. Value noise's weakness is a faint axis-aligned grid in the result, and
// the rotation between octaves below is what breaks that up.
//

float hash21 (vec2 p)
{
    // The classic sin-based hash. Its exact values differ between drivers - sin() of a
    // large argument is not bit-identical across implementations - which matters for
    // nothing here: clouds do not have to match anyone else's clouds.
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}

float valueNoise (vec2 p)
{
    vec2 i = floor(p);
    vec2 f = fract(p);

    // Quintic rather than smoothstep: its second derivative is zero at the lattice points
    // too, so a slowly drifting cloud does not show a faint crease every time it crosses
    // one. Cheap insurance - three multiplies - against an artifact that only appears once
    // something is moving.
    vec2 u = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);

    float a = hash21(i);
    float b = hash21(i + vec2(1.0, 0.0));
    float c = hash21(i + vec2(0.0, 1.0));
    float d = hash21(i + vec2(1.0, 1.0));

    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

/**
 * Octaves of value noise, each one finer and fainter than the last.
 *
 * Every octave is rotated as well as scaled. Doubling the frequency alone leaves all the
 * octaves sharing the same lattice directions, and they reinforce each other into visible
 * horizontal and vertical streaks; a rotation of about 0.5 radians per octave means no two
 * lattices line up.
 */
float fbm (vec2 p)
{
    const mat2 R = mat2(0.87758, -0.47943, 0.47943, 0.87758);   // 0.5 rad

    float sum = 0.0;
    float amplitude = 0.5;
    float total = 0.0;

    // CLOUD_OCTAVES rather than a parameter: GLSL 120 wants a loop bound it can see at
    // compile time, and a count passed in as an argument is not one.
    for (int i = 0; i < CLOUD_OCTAVES; i++) {
        sum += valueNoise(p) * amplitude;
        total += amplitude;
        p = R * p * 2.0;
        amplitude *= 0.5;
    }

    return sum / max(total, 0.0001);
}
