//
// A sky, a sun, and a layer of cloud - none of which exist in the scene.
//
// Everything here is analytic. There is no cloud geometry to render and nowhere to put it:
// this mod runs after the scene is drawn and can only repaint pixels. What makes that work
// is that the sky in this game is exactly the pixels the depth buffer never wrote to, so
// "sky" is a test any pass can make, and a view ray through such a pixel is known to have
// left the level without hitting anything.
//
// The cloud layer is a PLANE at CLOUD_HEIGHT, not a volume. A volumetric cloud needs a
// march of twenty-odd steps per pixel with a lighting march inside it, and a flat layer
// seen from underneath - which is how a player of a third-person game sees the sky - is
// almost entirely convincing for a fraction of that. It falls apart if the camera ever
// climbs above the layer, which in this game it cannot.
//
// Requires: depthtex0, uInvProjection, uInvView, uCamera, uScreen, uTime (and view.glsl,
// noise.glsl).
//

/** The sun's direction in world space. Clyde's world is Z-up. */
vec3 sunWorld ()
{
    float az = radians(SUN_AZIMUTH);
    float el = radians(SUN_ELEVATION);
    float ce = cos(el);
    return normalize(vec3(ce * cos(az), ce * sin(az), sin(el)));
}

/** The world-space direction the camera is looking along, through this pixel. */
vec3 rayWorld (vec2 uv)
{
    // Any depth will do - the ray through a pixel is the same line whatever is on it - so
    // this uses the near plane, where the reconstruction is best conditioned.
    vec3 v = viewPosition(uv, 0.0);
    return normalize((uInvView * vec4(v, 0.0)).xyz);
}

/** Where the wind has carried the layer to by now, in world units. */
vec2 windOffset ()
{
    float a = radians(WIND_DIR);
    return vec2(cos(a), sin(a)) * (WIND_SPEED * uTime);
}

/**
 * How much cloud is at a point on the layer, 0..1.
 *
 * COVER is a threshold on the noise rather than a multiplier, which is what gives a sky
 * with gaps in it. Scaling the noise instead just makes a uniformly thicker or thinner haze
 * from horizon to horizon, and no real sky looks like that.
 */
float cloudDensity (vec2 p, float soft)
{
    float n = fbm(p * CLOUD_SCALE + windOffset() * CLOUD_SCALE);
    return smoothstep(CLOUD_COVER, min(1.0, CLOUD_COVER + soft), n);
}

/**
 * Where a ray meets the cloud layer, and how far along the ray that is.
 *
 * Two departures from a straight plane intersection, both forced by this game rather than
 * chosen. 1.0.0 did it the textbook way and drew no clouds at all.
 *
 * The height is measured from the CAMERA, not in absolute world coordinates. Nothing tells
 * this mod what altitude a level sits at, and a layer at world z = 90 is underground in a
 * level built at z = 400.
 *
 * And the layer is LIFTED towards the camera. Spiral Knights looks down at the knight from
 * above, so the sky that is actually on screen - when any is - sits at or a little below the
 * true horizon, where dir.z is around zero or negative. A plane overhead is behind the
 * camera for those rays and the intersection rejects every one of them. Adding CLOUD_LIFT
 * before the clamp tilts the layer until the band that IS in shot lands on it; the clamp
 * then stops a near-horizontal ray from running out to infinity and taking the noise
 * coordinates with it.
 *
 * What is lost is parallax accuracy - the layer is no longer flat overhead - and nobody can
 * see that in a band of sky a few hundred pixels tall. What is gained is clouds.
 */
vec2 cloudPoint (vec3 origin, vec3 dir, out float t)
{
    float height = max(1.0, CLOUD_HEIGHT);
    float dz = max(dir.z + CLOUD_LIFT, CLOUD_HORIZON);
    t = height / dz;
    return origin.xy + dir.xy * t;
}

/**
 * The colour of the empty sky along a ray: a gradient, a sun, and the sun's glow.
 *
 * The gradient is brighter and greyer at the horizon than overhead for the same reason the
 * real one is - a horizontal line of sight passes through several times as much air - and
 * the square root shapes it so most of the change happens in the lower part of the sky,
 * where the eye expects it.
 */
vec3 skyColor (vec3 dir)
{
    vec3 zenith  = vec3(SKY_ZENITH_R, SKY_ZENITH_G, SKY_ZENITH_B);
    vec3 horizon = vec3(SKY_HORIZON_R, SKY_HORIZON_G, SKY_HORIZON_B);
    // Ramped from BELOW the horizon rather than from zero. clamp(dir.z, 0, 1) is zero
    // across this camera's entire sky band, which paints all of it in one flat horizon
    // colour - the "bright skybox with no detail" 1.0.0 produced.
    vec3 c = mix(horizon, zenith, smoothstep(-0.35, 0.65, dir.z));

    vec3 sun = sunWorld();
    float towards = dot(dir, sun);
    vec3 sunColor = vec3(SUN_R, SUN_G, SUN_B);

    // The disc, sized in degrees, with a soft edge about a tenth of its width. A hard edge
    // aliases badly against a moving camera at any reasonable resolution.
    float radius = radians(max(0.05, SUN_SIZE));
    c = mix(c, sunColor * 1.6, smoothstep(cos(radius), cos(radius * 0.85), towards));

    // And the glow around it, which is not the disc getting bigger: it is light scattered
    // out of the beam by the air, so it has a much wider and much softer falloff.
    c += sunColor * SUN_GLOW * pow(max(0.0, towards), GLOW_FOCUS);

    return c;
}

/**
 * The cloud layer along a ray: its colour, with coverage in alpha.
 *
 * Lit with one extra sample rather than a march. Taking the density a short way TOWARDS the
 * sun answers "is there more cloud between this point and the light" - which is the whole
 * question a lighting march asks, at one sample instead of ten. Where the answer is yes the
 * point is in the shadow of its own cloud, and that single trick is most of what makes a
 * flat layer look like it has volume.
 */
vec4 cloudLayer (vec3 origin, vec3 dir)
{
    float t;
    vec2 p = cloudPoint(origin, dir, t);

    // Distant cloud covers a few pixels per feature, and keeping its edges as crisp as the
    // cloud overhead turns the far half of the sky into static the moment the camera moves.
    // Widening the coverage ramp with distance is a cheap stand-in for the mip level a
    // procedural field does not have.
    float far = smoothstep(CLOUD_DETAIL * 0.35, CLOUD_DETAIL, t);
    float soft = min(1.0, CLOUD_SOFT + far * 0.45);

    float density = cloudDensity(p, soft);
    if (density <= 0.001) return vec4(0.0);

    vec3 sun = sunWorld();
    float towardsSun = cloudDensity(p + sun.xy * (CLOUD_SUN_SHIFT / max(0.0001, CLOUD_SCALE)), soft);

    // Bright where the cloud faces the sun with nothing in the way, dark where it is
    // shadowed by more of itself.
    float lit = clamp(1.0 - towardsSun, 0.0, 1.0);
    vec3 color = mix(vec3(CLOUD_DARK), vec3(CLOUD_BRIGHT), lit) * vec3(SUN_R, SUN_G, SUN_B);

    // Fade with DISTANCE along the ray, not with angle above the horizon. Fading by angle
    // is the natural way to write it and it removes the clouds from precisely the part of
    // the sky this game shows you.
    float fade = 1.0 - smoothstep(CLOUD_DISTANCE * 0.55, CLOUD_DISTANCE, t);

    return vec4(color, density * fade);
}

/**
 * Whether this pixel has open sky somewhere above it, 0..1.
 *
 * Without a test like this a cloud drifting overhead shades the floor of a sealed room. The
 * sky half of this pack needs no such guard - underground there are no sky pixels, so
 * nothing gets painted - but the shadow half reads a world position and a noise field, and
 * neither of them knows there is a ceiling in the way.
 *
 * The probe walks from the pixel to the top of the screen asking the depth buffer whether
 * any of it is sky. In a level whose horizon is in shot it answers well. In Haven, where the
 * camera is pitched down far enough that no sky is on screen at all, it answers "sheltered"
 * standing in the open - which is why SHADOW_SHELTER defaults to 0 and this is opt-in.
 */
float skyAbove (vec2 uv)
{
    float hits = 0.0;
    for (int i = 1; i <= SKY_PROBE_TAPS; i++) {
        float v = mix(uv.y, 1.0, float(i) / float(SKY_PROBE_TAPS));
        if (depthAt(vec2(uv.x, v)) >= 0.9999) hits += 1.0;
    }
    return hits / float(SKY_PROBE_TAPS);
}

/**
 * How much cloud stands between a world-space point and the sun, 0..1.
 *
 * The same field, sampled where the sun's ray through this point crosses the layer. Cloud
 * shadows drifting across a level are the strongest evidence that the sky above it is real,
 * and they cost one noise lookup: the shadow of a cloud is not a light calculation here,
 * just the question of which part of the layer is overhead in the sun's direction.
 */
float cloudShadow (vec3 world)
{
    vec3 sun = sunWorld();
    if (sun.z < 0.05) return 0.0;        // sun on the horizon casts no usable shadow here

    // The layer sits CLOUD_HEIGHT above the camera, so that is where the sun's ray through
    // this surface has to be followed to.
    float height = (uCamera.z + CLOUD_HEIGHT) - world.z;
    if (height <= 0.0) return 0.0;

    vec2 p = world.xy + sun.xy * (height / sun.z);
    return cloudDensity(p, CLOUD_SOFT);
}
