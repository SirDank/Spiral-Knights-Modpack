#version 120
//
// One pass: paint the sky, and put its shadows on the ground.
//
// Both halves come out of the same cloud field, and that is the point of doing them
// together. A sky with clouds in it and a level with shadows on it that do not match is
// worse than either alone - the eye catches the disagreement immediately - so the shadow a
// pixel receives is looked up in the very same noise that drew the cloud overhead.
//
// The split is by depth: a pixel the scene never wrote to is sky and gets repainted; a
// pixel with geometry on it keeps its colour and gets shaded.
//
#include "lib/view.glsl"
#include "lib/noise.glsl"
#include "lib/clouds.glsl"

void main ()
{
    vec2 uv = gl_TexCoord[0].st;
    vec4 base = texture2D(colortex0, uv);
    float depth = depthAt(uv);
    vec3 c = base.rgb;
    vec3 dir = rayWorld(uv);

#if SHOW == 1
    // Is there any sky in this shot at all? White where the depth buffer was never written.
    // In most of Haven the answer is none, which is worth knowing before blaming the clouds.
    gl_FragColor = vec4(vec3(depth >= 0.9999 ? 1.0 : 0.0), 1.0); return;
#elif SHOW == 2
    // Which way the view ray points. Green above the true horizon, red below it, black at
    // it. A screen that is entirely red is a camera that cannot see a plane overhead, which
    // is what CLOUD_LIFT exists to work around.
    gl_FragColor = vec4(max(0.0, -dir.z) * 2.0, max(0.0, dir.z) * 2.0, 0.0, 1.0); return;
#elif SHOW == 3
    // The cloud field itself, everywhere, sky or not: is there structure in it, at the
    // scale the options ask for?
    float t3;
    vec2 p3 = cloudPoint(uCamera.xyz, dir, t3);
    gl_FragColor = vec4(vec3(cloudDensity(p3, CLOUD_SOFT)), 1.0); return;
#elif SHOW == 4
    // How far along the ray the layer is met, log scaled: black at ten units, white at ten
    // thousand. Solid white means the rays are running off to the horizon and the noise
    // coordinates with them.
    float t4;
    cloudPoint(uCamera.xyz, dir, t4);
    gl_FragColor = vec4(vec3(clamp(log2(max(t4, 1.0)) / 13.0, 0.0, 1.0)), 1.0); return;
#endif

    if (depth >= 0.9999) {
        vec3 sky = skyColor(dir);

#if CLOUDS
        vec4 cloud = cloudLayer(uCamera.xyz, dir);
        sky = mix(sky, cloud.rgb, cloud.a);
#endif

        // SKY_REPLACE below 1 leaves some of the level's own skybox showing through, which
        // is the setting to reach for in a zone whose sky is part of its identity - the
        // painted sky over Haven, the furnace glow under the Firestorm Citadel.
        c = mix(base.rgb, sky, SKY_REPLACE);
    } else {
        // Sunlight and cloud shadow are the same privilege: both require that the sun can
        // see this pixel at all. Under a roof neither applies, and the level keeps the
        // lighting its own artists gave it.
        float exposed = mix(1.0, skyAbove(uv), SHADOW_SHELTER);

#if CLOUD_SHADOWS
        vec3 world = (uInvView * vec4(viewPosition(uv, depth), 1.0)).xyz;
        float shade = cloudShadow(world) * SHADOW_STRENGTH * exposed;

        // Shade is not darkness. A surface out of the sun is still lit - by the sky, which
        // is blue - so shadow cools as well as dims, and the sunlit ground takes the sun's
        // own colour. Dimming alone is the thing that makes fake shadows look like dirt.
        vec3 shadeColor = mix(vec3(1.0), vec3(1.0 - SHADOW_COOL * 0.35,
                                              1.0 - SHADOW_COOL * 0.18,
                                              1.0), shade);
        c = base.rgb * shadeColor * (1.0 - shade * 0.45);
        c = mix(c, c * vec3(SUN_R, SUN_G, SUN_B), DAY_WARMTH * (1.0 - shade) * exposed);
#else
        c = mix(c, c * vec3(SUN_R, SUN_G, SUN_B), DAY_WARMTH * exposed);
#endif
    }

    gl_FragColor = vec4(clamp(c, 0.0, 1.0), base.a);
}
