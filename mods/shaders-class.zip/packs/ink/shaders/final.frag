#version 120
//
// Pass 2 of 2: flatten the colour, lay the ink over it, and print the whole thing on paper.
//
// The order matters and is the reverse of how it might read. Banding happens first, on the
// clean image, because quantising a picture that already has ink in it quantises the ink
// too and the lines come out ragged. Hatching is decided from the banded brightness, so a
// band and its hatching agree. Grain and vignette go on last, over everything, because they
// are properties of the paper rather than of the drawing.
//
#include "lib/view.glsl"

/**
 * Posterise, without moving any hue.
 *
 * The obvious implementation quantises each channel independently, which slides colours
 * towards the corners of the cube as the step count drops: a brown floor at four bands goes
 * red, and a teal wall goes green. Quantising LUMINANCE and rescaling the colour as a whole
 * keeps the ratios between the channels, and the ratio is the hue.
 *
 * The softness parameter is what keeps a band boundary from crawling. A hard floor() puts a
 * hard edge wherever brightness happens to cross a step, and that edge slides across a
 * surface as the camera moves. Ramping over a window around the step turns it into a
 * dithered-looking transition that stays put.
 */
vec3 posterise (vec3 c, float l)
{
    if (l <= 0.0001) return c;

    float steps = float(BANDS);
    float x = l * steps;
    float s = max(0.001, BAND_SOFTNESS * 0.5);
    float banded = (floor(x) + smoothstep(0.5 - s, 0.5 + s, fract(x))) / steps;

    return c * mix(1.0, banded / l, BAND_STRENGTH);
}

/**
 * One set of parallel lines, as coverage in 0..1.
 *
 * `scale` is lines per ten pixels, which is a size a person can picture; the triangle wave
 * gives a line profile that is symmetrical about its centre, so widening a line grows it
 * evenly on both sides instead of sliding it sideways.
 *
 * The hatching is fixed to the SCREEN, not to the surface it darkens, and slides across the
 * world as the camera turns. That is deliberate: this is an engraving, and the lines belong
 * to the paper. Anchoring them to the geometry would need a stable surface parameterisation,
 * and a depth buffer cannot supply one - world-space hatching from reconstructed positions
 * swims just as badly the moment a surface faces away from the camera.
 */
float hatch (vec2 px, float angle, float scale, float darkness)
{
    vec2 dir = vec2(cos(angle), sin(angle));
    float v = dot(px, vec2(-dir.y, dir.x)) * (scale * 0.1);

    // Distance from the nearest line centre, 0..1.
    float f = abs(fract(v) - 0.5) * 2.0;

    // A darker area gets wider strokes, not more of them: extra strokes would change the
    // texture of the shading, while widening reads as more ink.
    float width = clamp(darkness, 0.0, 1.0) * 0.85;
    return 1.0 - smoothstep(width - 0.18, width + 0.02, f);
}

void main ()
{
    vec2 uv = gl_TexCoord[0].st;
    vec3 c = texture2D(colortex0, uv).rgb;
    float alpha = texture2D(colortex0, uv).a;
    bool sky = depthAt(uv) >= 0.9999;

    float l = dot(c, LUMA);
    c = posterise(c, l);

    // Saturation against the banded luminance, so the two agree about how bright this
    // pixel now is; using the original would drag colours back towards where they were.
    float lb = dot(c, LUMA);
    c = mix(vec3(lb), c, SATURATION);

    // Paper shows through the picture: a warm tint everywhere, and the lightest band lifted
    // most of the way to the paper's own colour, which is what makes the brightest areas
    // read as "unprinted" rather than as "white object".
    vec3 paper = vec3(1.0, 0.965, 0.90);
    c = mix(c, c * paper, PAPER);
    c = mix(c, paper, PAPER * 0.45 * smoothstep(0.72, 1.0, lb));

    float ink = texture2D(colortex1, uv).r * INK_STRENGTH;

#if HATCH
    // Hatching stands in for the shadow the banding just flattened. It is keyed off the
    // banded brightness rather than the original, so a band edge and the hatching that
    // starts there land in the same place; keyed off the original they disagree by a pixel
    // or two everywhere, which reads as a fringe.
    if (!sky) {
        float darkness = 1.0 - clamp(lb / max(0.001, HATCH_LEVEL), 0.0, 1.0);
        float h = hatch(gl_FragCoord.xy, HATCH_ANGLE, HATCH_SCALE, darkness);

        // The second set crosses the first only in the darkest areas - that is what
        // "cross-hatching" means, and applying both everywhere just doubles the density.
        float crossDark = 1.0 - clamp(lb / max(0.001, CROSS_LEVEL), 0.0, 1.0);
        if (crossDark > 0.0) {
            h = max(h, hatch(gl_FragCoord.xy, HATCH_ANGLE + 1.35, HATCH_SCALE, crossDark));
        }
        ink = max(ink, h * HATCH_STRENGTH);
    }
#endif

    c = mix(c, vec3(INK_R, INK_G, INK_B), clamp(ink, 0.0, 1.0));

    // Paper tooth. Interleaved gradient noise rather than a hash: its values spread evenly
    // over any small neighbourhood, so the grain looks like a texture instead of like a
    // handful of bright pixels.
    float g = ign(gl_FragCoord.xy / max(0.2, GRAIN_SCALE)) - 0.5;
    c *= 1.0 + g * GRAIN * 2.0;

    vec2 d = uv - 0.5;
    c *= 1.0 - VIGNETTE * dot(d, d) * 2.0;

    gl_FragColor = vec4(clamp(c, 0.0, 1.0), alpha);
}
