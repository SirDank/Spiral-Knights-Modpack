#version 120
//
// Pass 1 of 2: find the lines.
//
// A pen-and-ink picture is mostly its lines, and the depth buffer knows where they are:
// an artist draws an outline where one surface ends and another begins, and a crease where
// a surface folds. Both are visible in depth alone - neither needs to know what anything is
// made of.
//
// The three detectors here answer three different questions, and they are kept separate
// because they fail in different places:
//
//  - CURVATURE finds occlusion boundaries. The second difference of linear depth is zero on
//    any plane, however steeply it is tilted away from the camera, which is the property a
//    plain depth gradient lacks: a gradient draws a line down every sloped floor in Haven.
//
//  - The CREASE test finds folds, where depth stays continuous but the surface turns. It
//    compares the direction from the left neighbour with the direction to the right one, in
//    view space, so it measures an angle rather than a distance and does not have to be
//    rescaled with the distance to the camera.
//
//  - LUMA finds what the artwork itself drew - tile joins, panel lines, the painted detail
//    in the textures. Geometry knows nothing about those.
//
// Output is a single channel: how much ink this pixel gets, before any of it is coloured.
//
#include "lib/view.glsl"

/**
 * Where the screen-door transparency is, so no detector fires on it.
 *
 * Spiral Knights fades an occluding wall out with a one-pixel checkerboard between the wall
 * and what stands behind it. Depth there alternates between two surfaces metres apart, and
 * every detector above reads that as the most detailed geometry it has ever seen: without
 * this, walking behind a wall fills a third of the screen with solid ink.
 *
 * This is the dither half of `surfaceInfo`'s `guard`, on its own. The rest of that guard
 * rejects silhouettes and grazing angles - which is exactly where this pack most wants to
 * draw - so the combined value cannot be used here.
 *
 * The signature: in a dithered region a pixel matches its neighbour TWO along much better
 * than the one beside it. Real geometry never does that.
 */
float ditherMask (vec2 uv, vec2 t)
{
    float d0  = depthAt(uv);
    float dr  = depthAt(uv + vec2(t.x, 0.0));
    float dr2 = depthAt(uv + vec2(t.x * 2.0, 0.0));
    float du  = depthAt(uv + vec2(0.0, t.y));
    float du2 = depthAt(uv + vec2(0.0, t.y * 2.0));

    float alternation = max(abs(d0 - dr) - abs(d0 - dr2),
                            abs(d0 - du) - abs(d0 - du2));
    return clamp(alternation * 600.0, 0.0, 1.0);
}

float luma (vec2 uv)
{
    return dot(texture2D(colortex0, uv).rgb, LUMA);
}

void main ()
{
#if !OUTLINE
    gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
    return;
#else
    vec2 uv = gl_TexCoord[0].st;
    vec2 t = uScreen.zw;

    // The sampling ring doubles as the line width: a wider ring finds the same edge from
    // further away, which thickens every line by the same amount without a second dilation
    // pass. The cost is that a tight curve reads as an edge from both sides at width 4.
    vec2 w = t * float(OUTLINE_WIDTH);

    float d0 = depthAt(uv);
    float dl = depthAt(uv - vec2(w.x, 0.0));
    float dr = depthAt(uv + vec2(w.x, 0.0));
    float dd = depthAt(uv - vec2(0.0, w.y));
    float du = depthAt(uv + vec2(0.0, w.y));

    bool sky0 = d0  >= 0.9999;
    bool skyl = dl  >= 0.9999;
    bool skyr = dr  >= 0.9999;
    bool skyd = dd  >= 0.9999;
    bool skyu = du  >= 0.9999;

    // The silhouette against the sky, taken first and separately.
    //
    // It is the one line in the picture that is never in doubt, and it must not be put
    // through the same threshold as the rest: at the far plane linear depth is enormous, so
    // any relative measure either saturates or vanishes depending on how it is normalised.
    // Testing the sky flag directly sidesteps the arithmetic entirely.
    float silhouette = 0.0;
    if (sky0 != skyl || sky0 != skyr || sky0 != skyd || sky0 != skyu) silhouette = SILHOUETTE;

    // Everything below is measured in world units, and the sky has no position, so a
    // neighbour in the sky is replaced by the centre - it contributes nothing rather than
    // contributing the far plane.
    float z0 = linearDepth(d0, uNear, uFar);
    float zl = skyl ? z0 : linearDepth(dl, uNear, uFar);
    float zr = skyr ? z0 : linearDepth(dr, uNear, uFar);
    float zd = skyd ? z0 : linearDepth(dd, uNear, uFar);
    float zu = skyu ? z0 : linearDepth(du, uNear, uFar);

    float edge = 0.0;

    if (!sky0) {
        // Relative, not absolute: a 20cm step at two metres is an outline, the same step at
        // forty metres is a texture detail nobody would draw.
        float curvature = (abs(zl + zr - 2.0 * z0) + abs(zd + zu - 2.0 * z0)) / max(z0, 0.001);

        vec3 p0 = viewPosition(uv, d0);
        vec3 pl = viewPosition(uv - vec2(w.x, 0.0), dl);
        vec3 pr = viewPosition(uv + vec2(w.x, 0.0), dr);
        vec3 pd = viewPosition(uv - vec2(0.0, w.y), dd);
        vec3 pu = viewPosition(uv + vec2(0.0, w.y), du);

        // 1 - cos(fold angle) on each axis: 0 on a plane at any slope, rising as the
        // surface turns. Sky-side neighbours are skipped rather than normalised, since
        // normalize() of a zero vector is undefined.
        float crease = 0.0;
        if (!skyl && !skyr) crease += 1.0 - dot(normalize(p0 - pl), normalize(pr - p0));
        if (!skyd && !skyu) crease += 1.0 - dot(normalize(p0 - pd), normalize(pu - p0));

        // The artwork's own detail: a Laplacian on luminance. Signed sums cancel on a
        // gradient - a lit wall fading into shadow is not a line - and survive at a step.
        float l0 = luma(uv);
        float lap = abs(4.0 * l0
                        - luma(uv - vec2(w.x, 0.0)) - luma(uv + vec2(w.x, 0.0))
                        - luma(uv - vec2(0.0, w.y)) - luma(uv + vec2(0.0, w.y)));

        // The scale factors turn each raw measure into roughly the same range, so the three
        // weights above them are comparable and a threshold means one thing.
        edge = DEPTH_EDGE  * clamp(curvature * 24.0, 0.0, 4.0)
             + NORMAL_EDGE * clamp(crease    * 1.60, 0.0, 4.0)
             + LUMA_EDGE   * clamp(lap       * 2.20, 0.0, 4.0);

        edge *= 1.0 - ditherMask(uv, t);
    }

    float ink = smoothstep(EDGE_THRESHOLD, EDGE_THRESHOLD + EDGE_SOFTNESS, edge);
    ink = max(ink, silhouette);

    // Thin the lines out with distance, or the far half of a long room fills in solid: line
    // density is fixed in pixels while the geometry it is tracing keeps shrinking.
    //
    // Measured against the NEAREST surface in the neighbourhood, not the centre. On the sky
    // side of a silhouette the centre is at the far plane, and fading by that would rub out
    // precisely the line this pack cares most about.
    float nearest = min(min(z0, min(zl, zr)), min(zd, zu));
    ink *= 1.0 - smoothstep(LINE_FADE_START, max(LINE_FADE_START + 1.0, LINE_FADE_END), nearest);

    gl_FragColor = vec4(clamp(ink, 0.0, 1.0), 0.0, 0.0, 1.0);
#endif
}
