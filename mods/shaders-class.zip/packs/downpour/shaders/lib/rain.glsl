//
// Rain: the falling kind, the landed kind, and the weather around both.
//
// The honest limit of this pack, stated once here. A post-process has the colour buffer,
// the depth buffer and the camera - it has no idea whether the camera is under a roof.
//
// The first attempt at one was SKY ABOVE: walk up the screen from a pixel and ask the depth
// buffer whether any of it is sky. It is sound reasoning and it fails completely in this
// game, for a reason a screenshot makes obvious in a second and no amount of thinking about
// it did: the camera looks DOWN. Standing in the middle of Haven, in the open, with nothing
// overhead at all, there is not one sky pixel anywhere in the frame - so the probe reports
// "sheltered" and it never rains outdoors either.
//
// It is kept, because in a level whose horizon IS in shot it answers correctly, and because
// the alternative - asking the game - is not available. But RAIN_SHELTER now defaults to 0:
// rain everywhere. The cost of that is rain in a dungeon, which this game's camera renders
// almost unnoticeable, since it never shows you a ceiling either.
//
// Requires: depthtex0, uProjection, uInvProjection, uInvView, uScreen, uNear, uFar, uTime
// (and view.glsl, noise.glsl).
//

/** Aspect-corrected screen coordinates, so a drop is the same width however wide the window is. */
vec2 rainSpace (vec2 uv)
{
    return vec2(uv.x * (uScreen.x / max(1.0, uScreen.y)), uv.y);
}

/**
 * Whether this pixel has open sky somewhere above it, 0..1.
 *
 * Walks from the pixel to the top of the screen in SKY_PROBE_TAPS steps. The result is the
 * fraction of those taps that were sky rather than a hard yes/no: a pixel under the EDGE of
 * a roof then gets some rain rather than none, and the boundary between sheltered and
 * exposed is a gradient instead of a line that would crawl along the wall as the camera
 * moves.
 */
float skyAbove (vec2 uv)
{
    float hits = 0.0;
    for (int i = 1; i <= SKY_PROBE_TAPS; i++) {
        float v = mix(uv.y, 1.0, float(i) / float(SKY_PROBE_TAPS));
        if (depthAt(vec2(uv.x, v)) >= 0.9999) hits += 1.0;
    }
    return hits / float(SKY_PROBE_TAPS);
}

/**
 * One sheet of falling rain.
 *
 * The screen is divided into tall cells; a cell either holds a drop or it does not, decided
 * by a hash of its coordinates, and the drop falls by scrolling the whole grid upwards
 * through time. Nothing is remembered between frames - there is no place to remember it -
 * so a drop's entire life has to be a function of where it is and what time it is.
 *
 * Several sheets at different scales and speeds are what give rain its depth. A single
 * sheet reads as a moving texture stuck to the screen; three at different rates read as
 * rain at different distances, because that is genuinely the only cue the eye gets from
 * real rain too.
 */
float rainSheet (vec2 uv, float scale, float speed, float seed)
{
    vec2 p = rainSpace(uv) * vec2(RAIN_DENSITY * scale, RAIN_DENSITY * scale * 0.28);

    // Slant, applied as a shear on the falling axis: drops lean into the wind, and a
    // perfectly vertical sheet looks like a screensaver.
    p.x += p.y * RAIN_SLANT;

    // ADDING to p.y moves the pattern down the screen. A drop sits at a fixed cell, so the
    // screen position it appears at is (cell - scroll), and the sign that looks like it
    // should make rain fall is the one that makes it rise.
    p.y += uTime * RAIN_SPEED * speed;

    vec2 cell = floor(p);
    vec2 f = fract(p);

    float h = hash21(cell + seed);
    if (h > clamp(RAIN_AMOUNT, 0.0, 1.0)) return 0.0;   // this cell is empty

    // Where in its cell the drop sits, and how long it is. Both from the same cell hash, so
    // a drop keeps its identity for as long as the cell is on screen.
    float x = 0.15 + 0.7 * hash21(cell + seed + 7.31);
    float len = 0.35 + 0.55 * hash21(cell + seed + 3.17);

    // Across: a thin line with a soft edge. RAIN_WIDTH is in cell widths, which is why it
    // stays visually constant as RAIN_DENSITY changes.
    float across = 1.0 - smoothstep(0.0, RAIN_WIDTH, abs(f.x - x));

    // Along: bright at the head, fading to nothing at the tail. A drop moving fast enough
    // to streak is brightest where it is now and dimmest where it was.
    float along = (1.0 - smoothstep(0.0, len, f.y)) * smoothstep(0.0, 0.08, f.y);

    return across * along;
}

/**
 * How floor-like this pixel is: 1 on ground facing the sky, 0 on a wall.
 *
 * Rain lands on horizontal surfaces, so everything that happens to wet ground has to find
 * the ground first, and the only thing available to find it with is the reconstructed
 * normal. `surfaceInfo`'s guard is used as-is here - unlike in a pack that draws outlines,
 * this one has every reason to back off at a silhouette or a dithered wall, where the
 * normal is a guess.
 */
float floorness (vec2 uv, float depth, out vec3 world)
{
    vec3 p = viewPosition(uv, depth);
    world = (uInvView * vec4(p, 1.0)).xyz;

    vec3 n;
    float guard;
    surfaceInfo(uv, p, n, guard);

    // Clyde's world is Z-up, so the world-space normal's z is how much a surface faces the
    // sky.
    float up = (uInvView * vec4(n, 0.0)).z;
    return smoothstep(0.45, 0.85, up) * guard;
}

/**
 * Expanding rings where drops strike, keyed to WORLD position rather than to the screen.
 *
 * This is the one effect in the pack that stays put when the camera moves, and it is worth
 * the extra arithmetic for exactly that reason: a ripple pinned to the screen would slide
 * across the floor and look like a defect in the glass. The floor is divided into world
 * cells, each cell spawns one ring at a time, and the cell's hash decides both where inside
 * it the drop lands and how far through its life that ring currently is - so neighbouring
 * rings are out of step with each other without anything having to be stored.
 */
float ripples (vec3 world)
{
    vec2 grid = world.xy * RIPPLE_SCALE;
    vec2 cell = floor(grid);

    float sum = 0.0;

    // The neighbouring cells matter: a ring grows past its own cell boundary, and without
    // the neighbours every ring would be clipped into a square.
    for (int y = -1; y <= 1; y++) {
        for (int x = -1; x <= 1; x++) {
            vec2 c = cell + vec2(float(x), float(y));
            float seed = hash21(c);

            // Phase through this ring's life, offset per cell so they do not pulse together.
            float life = fract(uTime * RIPPLE_RATE + seed);

            // Which go-round this cell is on. Drops are not a sprinkler system: a cell gets
            // a drop sometimes, and a different set of cells gets one next time. Hashing the
            // cycle number as well as the cell is what makes that happen without storing
            // anything - the cell that rippled last second is not the one rippling now.
            float cycle = floor(uTime * RIPPLE_RATE + seed);
            if (hash21(c + cycle * 1.731) > RIPPLE_CHANCE) continue;

            vec2 centre = c + vec2(hash21(c + 1.7), hash21(c + 4.3));
            float r = length(grid - centre);

            float radius = life * RIPPLE_SIZE;
            float ring = 1.0 - smoothstep(0.0, RIPPLE_WIDTH, abs(r - radius));

            // Fade as it spreads: the same energy over a longer circumference.
            sum += ring * (1.0 - life) * (1.0 - life);
        }
    }

    return clamp(sum * RAIN_AMOUNT, 0.0, 1.0);
}

/**
 * A lightning flash, as a function of the clock and nothing else.
 *
 * Every FLASH_PERIOD seconds is a slot; a hash of the slot number decides whether that slot
 * actually flashes, so strikes come at irregular intervals without any state being kept.
 * The envelope is a hard onset and an exponential decay with a flicker riding on it, which
 * is what a real multi-stroke flash does - the stroke you see is usually three or four in
 * quick succession.
 */
float lightning ()
{
    float slot = floor(uTime / max(0.5, FLASH_PERIOD));
    float into = uTime - slot * max(0.5, FLASH_PERIOD);

    float roll = hash21(vec2(slot, 91.7));
    if (roll > FLASH_CHANCE) return 0.0;

    // A brighter or fainter strike, again from the slot, so they are not all identical.
    float magnitude = 0.45 + 0.55 * hash21(vec2(slot, 13.1));

    float decay = exp(-into * 7.0);
    float flicker = 0.65 + 0.35 * sin(into * 74.0 + roll * 30.0);

    return clamp(decay * flicker, 0.0, 1.0) * magnitude;
}
