#version 120
//
// One pass: weather the light, wet the ground, and put the rain in front of it.
//
// Order is the order it happens in the world, and getting it wrong is visible. The storm
// grade goes first because it is the LIGHT, and everything after it is lit by that light.
// Mist sits between the camera and the scene, so it replaces colour. Wet ground and ripples
// are part of the surface, so they happen before the mist that hides them. Rain and
// lightning go last, because the drops are in front of everything and a flash lights the
// air itself.
//
#include "lib/view.glsl"
#include "lib/noise.glsl"
#include "lib/rain.glsl"

void main ()
{
    vec2 uv = gl_TexCoord[0].st;
    vec4 base = texture2D(colortex0, uv);
    vec3 c = base.rgb;

    float depth = depthAt(uv);
    bool sky = depth >= 0.9999;

    // --- the light ------------------------------------------------------------------
    //
    // An overcast sky is a huge, dim, blue light source, and that is the entire look: less
    // light, less colour in it, and what remains is cool. Desaturating towards luminance
    // and then cooling keeps hues where they are instead of rotating them towards blue.
    float l = dot(c, LUMA);
    c = mix(c, vec3(l), STORM_DESATURATE);
    c *= 1.0 - STORM_DARKEN;
    c = mix(c, c * vec3(0.80, 0.88, 1.06), STORM_COOL);

    // --- the ground -----------------------------------------------------------------
    vec3 world = vec3(0.0);
    float floors = 0.0;
    if (!sky) floors = floorness(uv, depth, world);

#if WET
    // Wet stone is darker and more saturated than dry stone - water fills the surface
    // roughness, so less light scatters straight back out and what does has been through
    // the material. Squaring the colour does both at once and is the cheapest honest model
    // of it there is.
    c = mix(c, c * c * 1.25, WETNESS * floors);
#endif

#if RIPPLES
    if (floors > 0.0) {
        float rings = ripples(world) * floors * RIPPLE_STRENGTH;
        // Added as light, not as colour: a ripple is a momentary change in which way the
        // water faces, and what that does is catch the sky.
        c += rings * vec3(0.72, 0.78, 0.88);
    }
#endif

    // --- the air --------------------------------------------------------------------
    //
    // Distance in heavy rain is lost to the rain itself, not to fog: there are simply
    // enough drops between here and there to hide it. The squall term makes that uneven, in
    // slow sheets drifting across the view, which is what the distance in real rain does.
    float dist = sky ? uFar : linearDepth(depth, uNear, uFar);
    float mist = 1.0 - exp(-dist / max(1.0, MIST_DISTANCE));
    float squall = mix(1.0, fbm(rainSpace(uv) * 2.5 + vec2(uTime * SQUALL_SPEED, 0.0)) * 1.6, SQUALL);
    mist *= MIST * RAIN_AMOUNT * squall;
    c = mix(c, vec3(MIST_R, MIST_G, MIST_B) * (1.0 - STORM_DARKEN), clamp(mist, 0.0, 1.0));

    // --- the rain -------------------------------------------------------------------
    //
    // Shelter is decided ONCE for the whole pass. It is the most expensive single thing in
    // this shader - SKY_PROBE_TAPS depth samples walking up the screen - and both the rain
    // and the lightning need the same answer, which cannot differ between them.
#if RAIN || LIGHTNING
    float exposed = mix(1.0, skyAbove(uv), RAIN_SHELTER);
#endif

#if RAIN
    if (exposed > 0.001) {
        float rain = 0.0;
        for (int i = 0; i < RAIN_LAYERS; i++) {
            float fi = float(i);

            // Further sheets are finer, slower across the screen and fainter - the three
            // cues that separate them into distances. They also get their own seed, or
            // every layer draws the same drops in the same cells.
            float scale = 1.0 + fi * 0.85;
            float speed = 1.0 / (1.0 + fi * 0.40);
            float fade  = 1.0 / (1.0 + fi * 0.85);

            rain += rainSheet(uv, scale, speed, fi * 31.7) * fade;
        }

        // Rain is not white; it is whatever light is falling through it, which in a storm
        // is the sky. Added rather than mixed - a drop is a highlight, and a highlight is
        // light arriving, not paint.
        c += clamp(rain, 0.0, 2.0) * RAIN_BRIGHT * exposed * RAIN_AMOUNT
             * vec3(0.76, 0.84, 0.96);
    }
#endif

#if LIGHTNING
    float flash = lightning() * FLASH_STRENGTH;
    if (flash > 0.0) {
        // Indoors still brightens, just less: the flash lights the whole sky, and what
        // reaches a corridor is what bounces in. Without that floor the world outside a
        // doorway would flash while the doorway itself stayed dark.
        float reach = mix(0.35, 1.0, exposed);
        c += flash * reach * vec3(0.86, 0.92, 1.0) * (1.0 - 0.45 * l);
    }
#endif

    gl_FragColor = vec4(clamp(c, 0.0, 1.0), base.a);
}
