#version 120
//
// Pass 3 of 3: choose sharp or blurred per pixel, then grade for the model-shop look.
//
// The blur arrives at half resolution and is read back with linear filtering, which is only
// acceptable because it is blur: interpolating between two samples of an image that is
// already smooth introduces nothing. The sharp image is never upsampled - it is the
// original buffer, untouched - so anything in focus keeps its full detail.
//
#include "lib/view.glsl"
#include "lib/dof.glsl"

/**
 * Contrast and saturation, both hue preserving.
 *
 * Model paint is flatter and more saturated than the world it imitates, and pushing
 * contrast is what sells the scale: a real photograph of something small, lit by a lamp a
 * few inches away, has harder shadows than a landscape ever does.
 *
 * Applied to luminance with the colour rescaled as a whole, for the same reason Aurora
 * does it that way: per-channel contrast drags saturated colours towards the primaries, so
 * the scene shifts hue as it steepens.
 */
vec3 grade (vec3 c)
{
    float l = dot(c, LUMA);
    if (l > 0.0001) {
        float curved = l * l * (3.0 - 2.0 * l);     // smoothstep: the natural S-curve
        c *= mix(l, curved, CONTRAST) / l;
    }
    return mix(vec3(dot(c, LUMA)), c, SATURATION);
}

void main ()
{
    vec2 uv = gl_TexCoord[0].st;
    vec4 sharp = texture2D(colortex0, uv);
    vec3 blurred = texture2D(colortex2, uv).rgb;

    float coc = cocAt(uv, focusDistance());

    // A ramp rather than a straight mix by CoC. At small radii the gather has barely moved
    // anything, so mixing it in proportionally only softens the image without blurring it -
    // the worst of both. Holding the sharp image until the blur is wide enough to be worth
    // having keeps the focus band genuinely crisp.
    vec3 c = mix(sharp.rgb, blurred, smoothstep(0.05, 0.45, coc));

    c = grade(c);

    // A photograph of a small object is taken close up, and a lens wide open enough for
    // this little depth of field always darkens its corners.
    vec2 d = uv - 0.5;
    c *= 1.0 - VIGNETTE * dot(d, d) * 2.2;

    gl_FragColor = vec4(clamp(c, 0.0, 1.0), sharp.a);
}
