//
// Where the focus plane is, and how far out of focus each pixel falls.
//
// Shared because three passes have to agree about it exactly: the half-resolution pass that
// gathers the blur, and the full-resolution pass that decides how much of that blur to use,
// must compute the same circle of confusion from the same focus distance, or the sharp and
// blurred images disagree at every boundary and the seam shows.
//
// Requires: depthtex0, uInvProjection, uScreen, uNear, uFar (and view.glsl).
//

/**
 * One autofocus tap: its distance, or 0 with the count left alone if it landed on sky.
 */
float probe (vec2 uv, inout float count)
{
    float d = depthAt(clamp(uv, vec2(0.0), vec2(1.0)));
    if (d >= 0.9999) return 0.0;      // sky is not something to focus on
    count += 1.0;
    return linearDepth(d, uNear, uFar);
}

/**
 * The distance the lens is focused on, in world units.
 *
 * Autofocus reads the depth buffer at a probe point rather than being handed a focus
 * distance by the game. There is nothing to ask: the mod sees a colour buffer, a depth
 * buffer and the camera matrices, and no notion of what the player is looking at. The probe
 * defaults to slightly below the centre of the screen, which is where the knight stands in
 * this game's over-the-shoulder camera.
 *
 * Five taps, averaged, rejecting sky. One tap makes the whole image breathe every time a
 * projectile or a tuft of grass crosses the probe; the spread is wide enough that a thin
 * object cannot carry the average on its own.
 */
float focusDistance ()
{
#if AUTOFOCUS
    vec2 c = vec2(FOCUS_X, FOCUS_Y);
    vec2 s = uScreen.zw * 12.0;

    float total = 0.0;
    float n = 0.0;

    // Unrolled rather than looped over an offset array: five taps in a cross, written out.
    total += probe(c,                          n);
    total += probe(c + vec2(-s.x, 0.0),        n);
    total += probe(c + vec2( s.x, 0.0),        n);
    total += probe(c + vec2(0.0, -s.y),        n);
    total += probe(c + vec2(0.0,  s.y),        n);

    // Nothing but sky under the probe: fall back to the manual distance rather than
    // focusing on the far plane, which would blur the entire foreground.
    return n > 0.0 ? total / n : FOCUS_DISTANCE;
#else
    return FOCUS_DISTANCE;
#endif
}

/**
 * How far out of focus a pixel is, 0..1, where 1 means the full MAX_COC radius.
 *
 * Two separate causes are combined here and they are genuinely different effects:
 *
 *  - DEPTH. The real one: distance from the focus plane, flat inside FOCUS_RANGE and then
 *    ramping. Near and far get their own strengths because a real lens is not symmetrical
 *    about the focus plane - foreground blur is stronger and softer-edged - and because
 *    heavy near blur is what makes a scene read as photographed close up.
 *
 *  - TILT. A band across the screen, ignoring depth entirely. This is the tilt-shift
 *    trick: a person reads a photograph with a narrow horizontal band of sharpness as a
 *    photograph of something small, because only a macro shot has depth of field that
 *    shallow. It is faked on purpose - the real thing tilts the lens plane, which a
 *    post-process cannot do - and it is what turns the Clockworks into a tabletop model.
 */
float cocAt (vec2 uv, float focus)
{
    float d = depthAt(uv);
    float z = d >= 0.9999 ? uFar : linearDepth(d, uNear, uFar);

    float dist = z - focus;
    float beyond = max(0.0, abs(dist) - FOCUS_RANGE);
    float depthCoc = clamp(beyond / max(0.001, FOCUS_FALLOFF), 0.0, 1.0)
                   * (dist < 0.0 ? NEAR_BLUR : FAR_BLUR);

    float band = abs(uv.y - TILT_CENTER);
    float tiltCoc = smoothstep(TILT_WIDTH, TILT_WIDTH + TILT_FALLOFF, band);

    return clamp(max(depthCoc, tiltCoc * TILT_STRENGTH), 0.0, 1.0);
}
