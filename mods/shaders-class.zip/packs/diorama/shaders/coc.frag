#version 120
//
// Pass 1 of 3: half-resolution colour with its circle of confusion attached.
//
// The gather pass needs both at once - colour to spread, and how far to spread it - and a
// pass can only bind so many textures before it is cheaper to pack them together. Alpha
// carries the CoC, which is why this is the only buffer in the pack whose alpha means
// something other than opacity.
//
// Half resolution is not a concession here; it is the point. Blur is low-frequency by
// definition, so a gather at half resolution costs a quarter of the taps and looks the
// same once it is mixed back under the sharp image.
//
#include "lib/view.glsl"
#include "lib/dof.glsl"

void main ()
{
    vec2 uv = gl_TexCoord[0].st;
    vec2 t = uScreen.zw;               // full-resolution texel: a half-res pixel spans two
    float focus = focusDistance();

    // A box of four full-resolution pixels, which is what this half-resolution pixel
    // actually covers. Point-sampling one of the four makes a thin bright object - a
    // projectile, a lamp - flicker in and out of the blur as the camera drifts.
    vec3 c = texture2D(colortex0, uv + vec2(-0.5, -0.5) * t).rgb
           + texture2D(colortex0, uv + vec2( 0.5, -0.5) * t).rgb
           + texture2D(colortex0, uv + vec2(-0.5,  0.5) * t).rgb
           + texture2D(colortex0, uv + vec2( 0.5,  0.5) * t).rgb;
    c *= 0.25;

    // The CoC takes the MAXIMUM of the four, not the average. Averaging lets a sharp pixel
    // drag its blurred neighbour towards sharpness, and the half-resolution grid then shows
    // up as a faint checker along every focus boundary. Taking the largest is the safe
    // direction to be wrong in: a pixel may be blurred slightly more than it should be,
    // which nobody can see, rather than less, which leaves hard edges inside soft areas.
    float coc = max(max(cocAt(uv + vec2(-0.5, -0.5) * t, focus),
                        cocAt(uv + vec2( 0.5, -0.5) * t, focus)),
                    max(cocAt(uv + vec2(-0.5,  0.5) * t, focus),
                        cocAt(uv + vec2( 0.5,  0.5) * t, focus)));

    gl_FragColor = vec4(c, coc);
}
