#version 120
//
// Pass 2 of 3: the blur itself - a disc gather, which is what makes it bokeh rather than a
// Gaussian.
//
// Why a disc and not two separable Gaussian passes, which would be far cheaper: a Gaussian
// has no shape. Out-of-focus light in a real lens takes the shape of the aperture, so a
// bright point becomes a hard-edged disc or hexagon, and that shape is the entire visual
// signature of shallow depth of field. A Gaussian turns the same point into a soft smudge
// that reads as "blurry image", not as "out of focus".
//
// Scatter-as-gather: the physical effect is that each out-of-focus pixel SCATTERS its light
// over a disc, which a fragment shader cannot do - a fragment writes one pixel. So each
// pixel instead gathers from every neighbour that would have scattered onto it, which is
// the same sum with the loop turned inside out. That is why the radius below is always the
// maximum, never this pixel's own: a sharp pixel standing in front of a blurred one still
// has to collect the light thrown at it from outside.
//
#include "lib/color.glsl"

/**
 * Interleaved gradient noise, for the per-pixel rotation below.
 *
 * Defined here rather than included: the copy in view.glsl comes with the depth helpers
 * around it, and this pass binds no depth texture for those to sample.
 */
float ign (vec2 p)
{
    return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715))));
}

/**
 * Radius multiplier that turns the unit disc into a regular polygon.
 *
 * A cheap lens has straight aperture blades, and its bokeh is a hexagon. The scale is the
 * ratio between the polygon's inradius and the distance to its edge at this angle: 1 at a
 * corner, cos(pi/n) along the middle of an edge.
 */
float apertureShape (float angle, float blades)
{
    float sector = 6.2831853 / blades;
    return cos(sector * 0.5) / cos(mod(angle, sector) - sector * 0.5);
}

void main ()
{
    vec2 uv = gl_TexCoord[0].st;
    vec4 centre = texture2D(colortex1, uv);

    // Radii are in full-resolution pixels throughout the pack, so the step is the
    // full-resolution texel even though this pass runs at half. uScreen reports the
    // display, which is what makes that work without a PASS_SCALE correction here.
    vec2 texel = uScreen.zw;

    // Per-pixel rotation of the whole spiral. Without it every pixel samples the same
    // angles and the disc edges line up into visible spokes; interleaved gradient noise
    // spreads those angles evenly over any small neighbourhood, so the spokes average out
    // instead of turning into static.
    float jitter = ign(gl_FragCoord.xy) * 6.2831853;

    vec3 sum = centre.rgb;
    float total = 1.0;

    for (int i = 0; i < BOKEH_SAMPLES; i++) {
        float fi = float(i) + 0.5;

        // sqrt spaces the samples evenly by AREA. Spacing them evenly by radius crowds the
        // centre and leaves the rim - which is where a disc's hard edge lives - undersampled.
        float r = sqrt(fi / float(BOKEH_SAMPLES));
        float a = fi * 2.39996323 + jitter;      // golden angle: no two samples line up

#if BOKEH_BLADES > 0
        r *= apertureShape(a, float(BOKEH_BLADES));
#endif

        float dist = r * MAX_COC;
        vec2 at = uv + vec2(cos(a), sin(a)) * dist * texel;
        vec4 s = texture2D(colortex1, at);

        // The occlusion test, and the reason foreground blur looks right. A sample only
        // contributes if its own circle of confusion is wide enough to have reached this
        // far: a sharp object standing in front of a blurred wall must not be smeared
        // across it, but a blurred hand in front of a sharp floor must spill over it.
        float w = 1.0 - smoothstep(s.a * MAX_COC - 1.0, s.a * MAX_COC + 1.0, dist);

        // Bright samples dominate, which is what makes a highlight resolve into a disc
        // rather than a pale haze. Weighting by luminance squared is arbitrary but stable;
        // the division below keeps the exposure honest either way.
        w *= 1.0 + HIGHLIGHT_BOOST * dot(s.rgb, LUMA) * dot(s.rgb, LUMA);

        sum += s.rgb * w;
        total += w;
    }

    gl_FragColor = vec4(sum / max(total, 0.0001), centre.a);
}
