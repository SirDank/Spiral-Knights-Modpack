#version 120
//
// Pass 3 of 3: put the air back in.
//
// Two things are happening and they are easy to confuse. FOG is extinction: distance
// replaces the colour of a surface with the colour of the air in front of it. RAYS are
// in-scattering: light bounced towards the camera by that same air, which ADDS. So fog is a
// mix and rays are a sum, and the rays go on afterwards - light scattered into the view has
// not travelled through the fog that is dimming the surface behind it.
//
#include "lib/view.glsl"
#include "lib/sky.glsl"

void main ()
{
    vec2 uv = gl_TexCoord[0].st;
    vec4 base = texture2D(colortex0, uv);
    vec3 c = base.rgb;

    float depth = depthAt(uv);
    bool sky = depth >= 0.9999;

#if FOG
    float dist;
    vec3 world = worldAt(uv, depth, dist);
    float f = fogAmount(uCamera.xyz, world, dist) * FOG_MAX;

    // The sky is already "the far distance"; fogging it as heavily as a surface at the same
    // nominal distance would paint over it completely. SKY_FOG is how much of the horizon
    // haze is allowed to reach it - the amount that makes a horizon appear at all.
    if (sky) f *= SKY_FOG;

    // Looking into the sun, the air between you and everything else is lit from behind and
    // takes the sun's colour. This is the cheap stand-in for that: it is a view-direction
    // effect, not a scattering integral, but it is the part of scattering the eye actually
    // reads.
    vec3 toPoint = normalize(viewPosition(uv, min(depth, 0.9999)));
    float towardsSun = max(0.0, dot(toPoint, sunView()));
    vec3 fogColor = mix(vec3(FOG_R, FOG_G, FOG_B),
                        vec3(SUN_R, SUN_G, SUN_B),
                        SUN_TINT * pow(towardsSun, SUN_TINT_FOCUS));

    // Colour drains with distance before brightness does - haze scatters short wavelengths
    // out of the line of sight, and what survives is greyer than what set out. Desaturating
    // before the mix rather than after keeps the near half of the picture untouched.
    c = mix(c, vec3(dot(c, LUMA)), AERIAL_DESATURATE * f);
    c = mix(c, fogColor, f);
#endif

#if RAYS
    c += texture2D(colortex2, uv).rgb * vec3(SUN_R, SUN_G, SUN_B) * RAY_WEIGHT;
#endif

    gl_FragColor = vec4(clamp(c, 0.0, 1.0), base.a);
}
