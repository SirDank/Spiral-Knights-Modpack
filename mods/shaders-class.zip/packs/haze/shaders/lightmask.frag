#version 120
//
// Pass 1 of 3: what is throwing light, and what is standing in front of it.
//
// God rays are the shadows of solid things cast through dusty air, so the input the blur
// pass needs is not "the bright parts of the picture" but "where light reaches the camera
// unobstructed". That is exactly the sky: a sky pixel is a line of sight that ran all the
// way out of the level without hitting anything. Every pixel of geometry is an occluder and
// contributes nothing, which is what carves the shafts.
//
// Built at half resolution. The result is about to be smeared along a radius twenty-odd
// samples long - there is no detail here to lose.
//
#include "lib/view.glsl"

void main ()
{
    vec2 uv = gl_TexCoord[0].st;
    vec3 c = texture2D(colortex0, uv).rgb;

    if (depthAt(uv) >= 0.9999) {
        // The sky's own colour, not white: rays through a red sky are red, and this game
        // has plenty of skies that are not blue.
        gl_FragColor = vec4(c, 1.0);
        return;
    }

#if RAYS_FROM_LIGHTS
    // Optional second source: things in the level bright enough to read as lights in their
    // own right - a lamp, a lava pool, a charged sword. Off by default, because a radial
    // blur from the sun's position is the wrong shape for light coming from somewhere else
    // in the room: the streaks will point the right way only by accident.
    float l = dot(c, LUMA);
    float over = smoothstep(RAY_THRESHOLD, min(1.0, RAY_THRESHOLD + 0.15), l);
    gl_FragColor = vec4(c * over, 1.0);
#else
    gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
#endif
}
