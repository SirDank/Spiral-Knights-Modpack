#version 120
//
// Pass 2 of 3: march from each pixel towards the sun, collecting whatever light was not
// blocked on the way.
//
// This is the 2004 Mitchell formulation - a radial blur along the line to the light - and
// it is still the right one here. A true volumetric would march the depth buffer in world
// space and test occlusion per step; it would also cost several times as much and could
// only ever see the same occluders, because a screen-space march cannot find a shaft whose
// blocker is off screen either way.
//
// The sun is placed in the WORLD, by azimuth and elevation, and projected to screen each
// frame. A sun pinned to a screen position instead would swing around the level as the
// camera turned and the illusion would last about one turn.
//
#include "lib/view.glsl"
#include "lib/sky.glsl"

void main ()
{
    vec2 uv = gl_TexCoord[0].st;

#if !RAYS
    gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0);
    return;
#else
    bool visible;
    vec2 sun = sunScreen(visible);
    if (!visible) { gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0); return; }

    // Step towards the sun, covering RAY_DENSITY of the way there.
    vec2 delta = (uv - sun) * (RAY_DENSITY / float(RAY_SAMPLES));

    // Start each pixel a fraction of a step along, so the sample positions do not line up
    // between neighbours. Without it the fixed step count draws concentric rings around the
    // sun wherever the mask has a hard edge.
    vec2 at = uv - delta * ign(gl_FragCoord.xy);

    vec3 sum = vec3(0.0);
    float illumination = 1.0;

    for (int i = 0; i < RAY_SAMPLES; i++) {
        at -= delta;
        sum += texture2D(colortex1, clamp(at, vec2(0.0), vec2(1.0))).rgb * illumination;
        illumination *= RAY_DECAY;
    }

    sum *= RAY_EXPOSURE / float(RAY_SAMPLES);

    // Fade the whole effect out as the sun leaves the screen. The march still produces
    // something for a sun just past the edge - the direction is still meaningful - but the
    // mask near the edge is increasingly a guess, and without this the rays snap off the
    // instant the projected point crosses the border.
    vec2 edge = smoothstep(-0.35, 0.12, sun) * smoothstep(-0.35, 0.12, 1.0 - sun);
    sum *= edge.x * edge.y;

    gl_FragColor = vec4(sum, 1.0);
#endif
}
