//
// Where the sun is, and how much air the picture is looking through.
//
// The sun is not in the depth buffer, the colour buffer, or any uniform this mod can reach:
// the scene's lighting lives on the server and is baked into the art. So this pack is told
// where the sun is - an azimuth and an elevation - and derives everything else from the
// camera matrices. That is why the rays stay put in the world as the camera turns, which is
// the whole difference between god rays and a bright smear that follows you around.
//
// Requires: depthtex0, uProjection, uInvProjection, uView, uScreen, uNear, uFar, uCamera
// (and view.glsl).
//

/** The sun's direction in world space. Clyde's world is Z-up. */
vec3 sunWorld ()
{
    float az = radians(SUN_AZIMUTH);
    float el = radians(SUN_ELEVATION);
    float ce = cos(el);
    return normalize(vec3(ce * cos(az), ce * sin(az), sin(el)));
}

/** The same direction in view space: -Z is forwards, so a visible sun has a negative z. */
vec3 sunView ()
{
    return normalize((uView * vec4(sunWorld(), 0.0)).xyz);
}

/**
 * Where the sun lands on screen, and whether it is in front of the camera at all.
 *
 * Projecting a direction means projecting a point a long way along it. "A long way" is a
 * thousand units, which is past anything the game draws and comfortably inside the range
 * where the projection is still numerically sane.
 */
vec2 sunScreen (out bool visible)
{
    vec3 v = sunView();
    visible = v.z < -0.05;          // behind the camera, or so near the plane of it that
    if (!visible) return vec2(0.5); // the projection would fling the point to infinity
    return project(v * 1000.0).xy;
}

/**
 * The world-space point the scene drew at this pixel, and how far away it is.
 *
 * Sky pixels have no position - depth there is the cleared far plane - so they are reported
 * at SKY_DISTANCE along the view ray instead, which is what gives the horizon its haze
 * without the arithmetic blowing up at the far plane.
 */
vec3 worldAt (vec2 uv, float depth, out float dist)
{
    vec3 vp = viewPosition(uv, min(depth, 0.9999));
    if (depth >= 0.9999) vp = normalize(vp) * SKY_DISTANCE;
    dist = length(vp);
    return (uInvView * vec4(vp, 1.0)).xyz;
}

/**
 * How much of the view to this point is air, 0..1.
 *
 * Exponential height fog, integrated analytically along the ray rather than sampled. Fog
 * that ignores height is the giveaway of a cheap atmosphere: it fills a pit and a mountain
 * top equally, so nothing ever rises out of it. Density here falls off exponentially with
 * height, and the closed form below is the integral of that density along the segment from
 * the camera to the point - exact, one expression, no marching.
 *
 *     density(h) = FOG_DENSITY * exp(-(h - FOG_BASE) / FOG_HEIGHT)
 *
 * The degenerate case is a horizontal ray, where the height never changes and the integral
 * is just density times length; the general form divides by the height difference, so it
 * has to be taken separately before that division loses all its precision.
 */
float fogAmount (vec3 camera, vec3 point, float dist)
{
    float dz = point.z - camera.z;
    float atCamera = FOG_DENSITY * exp(-(camera.z - FOG_BASE) / max(0.01, FOG_HEIGHT));

    float optical;
    if (abs(dz) < 0.001) {
        optical = atCamera * dist;
    } else {
        optical = atCamera * FOG_HEIGHT * (1.0 - exp(-dz / max(0.01, FOG_HEIGHT))) * dist / dz;
    }

    return clamp(1.0 - exp(-max(0.0, optical)), 0.0, 1.0);
}
