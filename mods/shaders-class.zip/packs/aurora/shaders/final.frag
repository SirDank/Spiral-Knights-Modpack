#version 120
//
// Pass 4 of 4: apply the blurred occlusion and shadow, then reflections.
//
// Reflections are computed here rather than in the shade pass because they need the scene
// colour, and they march deterministically - no jitter - so they band slightly at grazing
// angles instead of adding static back into an image the blur just cleaned up.
//
#include "lib/view.glsl"

/**
 * Colour grading, applied last.
 *
 * Every step here is deliberately *hue preserving*. The obvious way to write each of these
 * - clamp each channel, divide each channel by its own shoulder - changes the ratios
 * between R, G and B, and the ratio is the hue. That is what turned brown ground pink and
 * green grass acid: the red channel was being compressed hard while blue was untouched.
 *
 * So brightness scales all three equally, saturation slides along the line through grey
 * (which by construction keeps hue), and both the highlight shoulder and the final
 * out-of-range fix work on luminance and then scale the colour as a whole.
 */
/**
 * Pushes the lighting apart: dark areas darker, lit areas brighter.
 *
 * An S-curve on luminance rather than on the channels. Contrast applied per channel drags
 * saturated colours towards the primaries as it steepens - the red half of a brown gets
 * pushed while the blue half does not - so the scene shifts hue as it gets more dramatic.
 * Working on luminance and rescaling the colour as a whole keeps every hue exactly.
 *
 * BLACK_POINT subtracts before the curve, which is what actually lets shadows reach black;
 * an S-curve alone flattens toward the ends and never quite gets there.
 */
vec3 dramatise (vec3 c)
{
    float l = dot(c, LUMA);
    if (l <= 0.0001) return c;

    float lifted = max(0.0, (l - BLACK_POINT) / max(0.0001, 1.0 - BLACK_POINT));
    // smoothstep is the natural S: flat at both ends, steep through the middle.
    float curved = lifted * lifted * (3.0 - 2.0 * lifted);
    return c * (mix(lifted, curved, DRAMA) / l);
}

vec3 grade (vec3 c)
{
    c = max(c * BRIGHTNESS, 0.0);
    c = max((c - 0.5) * CONTRAST + 0.5, 0.0);

    float luma = dot(c, LUMA);
    c = max(mix(vec3(luma), c, SATURATION), 0.0);

    // Highlight shoulder, on luminance. Asymptotic, so it approaches white without ever
    // reaching it - no flat blown-out panels on Spiral Knights' bright palette.
    luma = dot(c, LUMA);
    if (luma > HIGHLIGHT_ROLLOFF && luma > 0.0001) {
        float head = 1.0 - HIGHLIGHT_ROLLOFF;
        float rolled = HIGHLIGHT_ROLLOFF + head * (1.0 - exp(-(luma - HIGHLIGHT_ROLLOFF) / head));
        c *= rolled / luma;
    }

    // Anything still outside the display range is scaled down as a whole.
    //
    // The previous version desaturated towards luminance until the peak fitted, which is a
    // standard gamut clip and wrong here. When luminance is already high - a bright tile
    // with a bright bloom on top - pulling the peak down to 1.0 drags the OTHER channels
    // up, and a saturated orange (1.42, 0.75, 0.30) comes out (1.00, 0.83, 0.72): white.
    // That is what put white blobs under the lit tiles.
    //
    // Dividing by the peak keeps every channel ratio, so the same colour lands at
    // (1.00, 0.53, 0.21) and stays orange. It costs brightness rather than hue, which is
    // the right thing to spend: a glowing object that stops getting brighter still reads as
    // glowing, one that turns white reads as broken.
    float peak = max(c.r, max(c.g, c.b));
    if (peak > 1.0) {
        // Scaling to fit keeps hue exactly, and on its own it means something already at
        // full saturation can never get brighter - a projectile plus its bloom normalises
        // straight back to the projectile. Nothing then reads as EMITTING light.
        //
        // A real light source does go white at its core, in a camera and in the eye. The
        // earlier mistake was whitening things that were merely lit; gating it on how far
        // past the display range a colour actually is keeps that from returning, because a
        // lit surface overshoots slightly and a light source overshoots a lot.
        vec3 scaled = c / peak;
        float excess = clamp((peak - 1.0) / WHITE_POINT, 0.0, 1.0);
        c = mix(scaled, vec3(1.0), excess * WHITE_CORE);
    }
    return clamp(c, 0.0, 1.0);
}

vec4 reflection (vec3 p, vec3 n)
{
    vec3 dir = normalize(reflect(normalize(p), n));
    if (dir.z > 0.0) return vec4(0.0);   // pointing back at the eye; nothing on screen to find

    vec3 stride = dir * (SSR_LENGTH / float(SSR_STEPS));

    for (int i = 1; i <= SSR_STEPS; i++) {
        vec3 samplePos = p + stride * float(i);
        vec3 proj = project(samplePos);
        if (!onScreen(proj.xy)) break;

        float diff = scenePosition(proj.xy).z - samplePos.z;
        if (diff > 0.0 && diff < SSR_THICKNESS) {
            vec2 edge = smoothstep(0.0, 0.15, proj.xy) * smoothstep(0.0, 0.15, 1.0 - proj.xy);
            float confidence = edge.x * edge.y * (1.0 - float(i) / float(SSR_STEPS));
            return vec4(texture2D(colortex0, proj.xy).rgb, confidence);
        }
    }
    return vec4(0.0);
}

void main ()
{
    vec2 uv = gl_TexCoord[0].st;
    vec4 base = texture2D(colortex0, uv);
    float depth = depthAt(uv);

    // Sky still gets graded - it is part of the picture - but nothing else applies to it.
    if (depth >= 0.9999) {
        // Sky takes bloom and grading, but never occlusion or shadow.
        vec3 sky = base.rgb;
#if BLOOM
        sky += texture2D(colortex8, uv).rgb;
#endif
        gl_FragColor = vec4(grade(sky), base.a);
        return;
    }

    // rgb = bounced light, a = combined occlusion and sun shadow
    vec4 shade = texture2D(colortex3, uv);

    // Direct term: the surface as drawn, darkened by what it cannot see.
    vec3 color = base.rgb * shade.a;

#if GI
    // Indirect term: bounced light times this surface's own colour. Light that reaches a
    // red floor and leaves again is red - multiplying by the base is what carries the
    // colour of one surface onto its neighbour.
    color += base.rgb * shade.rgb * GI_STRENGTH;
#endif

#if SSR
    vec3 p = viewPosition(uv, depth);
    vec3 n;
    float confidence;
    surfaceInfo(uv, p, n, confidence);

    vec4 refl = reflection(p, n);
    refl.a *= confidence;

    // Reflect floors, not walls.
    //
    // There is no material or roughness information anywhere in this pipeline - the depth
    // buffer says where a surface is, never what it is made of - so applied uniformly, SSR
    // turns every surface into polished glass, walls included. Upward-facing surfaces are
    // the ones that read as plausibly reflective (wet stone, polished floor); a vertical
    // wall reflecting its surroundings just looks wrong.
    //
    // Clyde's world is Z-up, so the world-space normal's z is how much a surface faces the
    // sky. Set SSR_FLOOR_ONLY to 0 to reflect everything again.
#if SSR_FLOOR_ONLY
    float facingUp = (uInvView * vec4(n, 0.0)).z;
    // A wide ramp on purpose: a hard threshold makes reflections pop on and off as a
    // surface tilts past it while the camera moves.
    refl.a *= smoothstep(SSR_FLOOR_BIAS, SSR_FLOOR_BIAS + 0.45, facingUp);
#endif

    if (refl.a > 0.0) {
        float fresnel = pow(1.0 - max(0.0, dot(n, normalize(-p))), 3.0);
        color = mix(color, refl.rgb, refl.a * fresnel * SSR_STRENGTH);
    }
#endif

#if DRAMATIC
    color = dramatise(color);
#endif

#if BLOOM
    // Added after the drama curve, not before: bloom is light arriving on top of the
    // image, so darkening the scene must not darken the glow with it.
    //
    // Two scales summed. A single gaussian can be bright or wide but not both: blurring a
    // small bright spot over N pixels divides its peak by N, so widening the glow to look
    // like a light source dims it to nothing. The tight pass keeps the core bright, the
    // wide pass supplies the halo that reads as a glow.
    color += texture2D(colortex8, uv).rgb;   // both scales, already weighted
#endif

#if SHOW == 1
    // Indirect light alone, amplified - what the bounce is actually contributing.
    gl_FragColor = vec4(shade.rgb * 4.0, 1.0); return;
#elif SHOW == 2
    // Visibility alone: occlusion and sun shadow combined. White = fully lit.
    gl_FragColor = vec4(vec3(shade.a), 1.0); return;
#elif SHOW == 3
    // colortex8, not colortex6: the two bloom scales are summed in the wide pass so the
    // composite stays within four texture units, and colortex6 is not bound here.
    gl_FragColor = vec4(texture2D(colortex8, uv).rgb, 1.0); return;
#endif

    gl_FragColor = vec4(grade(color), base.a);
}
