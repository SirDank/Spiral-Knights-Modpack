#version 120
// Bloom pass 2: spread across the screen.
#include "lib/color.glsl"
#include "lib/bloom.glsl"

void main ()
{
    gl_FragColor = vec4(bloomBlur(colortex4, gl_TexCoord[0].st, vec2(1.0, 0.0), BLOOM_SCALE), 1.0);
}
