#version 120
//
// Theme pass: what is this level like, and what should the sky look like because of it?
//
// Two answers, from a coarse grid of the scene's own pixels (never the sky, which the sky
// pass is about to replace):
//
//   MEAN    the average colour of everything on screen - how bright and how warm the level is
//           overall. A dark brown dungeon is dark brown.
//   ACCENT  the average of the vivid, bright pixels only. The same dungeon's purple lights,
//           which the mean drowns in floor.
//
// The sky takes its time of day from the first and its hue from the second. Neither comes from
// a table, so a texture pack that recolours the terrain recolours the sky with it.
//
// WHEN it looks, and what the sky sees meanwhile, is most of what is hard here. (The
// timings below are options: a short warm-up and window with SKY_THEME_SPEED at 1 snaps to a
// new place almost at once; lengthen them if the picture takes a while to fill in.)
//
//   - The mod counts places entered (uEpoch). For the first moments of a place this pass
//     watches and averages, and then it LOCKS: a level has one look, and a theme that follows
//     the picture has the sky pulsing with every spell.
//   - While it is still working, the sky is NOT shown what it is working on. The first moments
//     of a place are the picture fading in and the camera settling, so the answer swings
//     about; showing that is the rapid change this was written to remove. The sky keeps the
//     last settled theme, and eases to the new one only once it is final.
//   - It remembers. A fingerprint of how a place looked at the end of the warm-up (mean and
//     accent) is stored with the final answer, per session, in a second small buffer
//     (mem.frag). Entering something that looks like a place seen before skips the rest of
//     the capture and eases straight to what was found last time.
//
// A render target is this pass's only memory, and nothing in this engine clears one, so each
// frame it reads the last frame's answer back and writes a new one. The state is in six
// regions across the buffer, six cells wide, each holding an rgb colour and a flag in alpha:
//
//   0  captured mean           alpha: which epoch this belongs to
//   1  captured accent         alpha: frames captured so far
//   2  SHOWN mean              alpha: 1 once set        <- what the sky reads
//   3  SHOWN accent            alpha: 1 once set        <- what the sky reads
//   4  fingerprint, mean       alpha: 1 once taken
//   5  fingerprint, accent     alpha: 1 if this place was recognised rather than captured
//
// Reads: scene, depthtex0, themeprev, memprev.
//
const float COLS = 32.0;
const float ROWS = 18.0;

#define REG(r) texture2D(themeprev, vec2((float(r) + 0.5) / 6.0, 0.5))
#define MEMC(c) texture2D(memprev, vec2((float(c) + 0.5) / 48.0, 0.5))

/**
 * Moves a colour towards a target, and never jitters.
 *
 * Storage is 8-bit, so a slow approach has a trap in it: a step smaller than 1/255 rounds
 * away and the colour stalls short of where it is going. Each step here is a fraction of the
 * remaining distance but never less than one storage step, and nothing moves within a step
 * and a half of the target. Deterministic, and identical in every pixel of the buffer, so
 * there is no noise to average away and none to see.
 */
vec3 approach (vec3 cur, vec3 target, float rate)
{
    vec3 d = target - cur;
    vec3 ad = abs(d);
    vec3 stepv = max(ad * rate, vec3(1.0 / 255.0));
    return cur + sign(d) * stepv * vec3(greaterThan(ad, vec3(1.5 / 255.0)));
}

void main ()
{
    // ---- look at the picture -----------------------------------------------------------
    vec3 meanSum = vec3(0.0);
    float meanN = 0.0;
    vec3 vividSum = vec3(0.0);
    float vividW = 0.0;

    for (int j = 0; j < 18; j++) {
        for (int i = 0; i < 32; i++) {
            vec2 uv = (vec2(float(i), float(j)) + 0.5) / vec2(COLS, ROWS);
            if (texture2D(depthtex0, uv).r >= 0.9999) continue;     // sky: not ours to count

            vec3 c = min(texture2D(scene, uv).rgb, vec3(1.0));
            float mx = max(c.r, max(c.g, c.b));
            float mn = min(c.r, min(c.g, c.b));
            float sat = (mx - mn) / max(mx, 0.001);
            float l = dot(c, vec3(0.2126, 0.7152, 0.0722));

            // A spell or a flash lighting the whole screen is not the level getting
            // brighter; near-white counts for little in the mean.
            float wm = 1.0 - 0.9 * smoothstep(0.72, 0.95, l);
            meanSum += c * wm;
            meanN += wm;

            // Vivid AND bright: a saturated pixel that is also well lit is a light or a
            // painted feature. Squared saturation so a faint tint counts for nothing, and
            // not-quite-white only, since a blown-out flash has no colour left to give.
            float w = sat * sat * smoothstep(0.28, 0.62, mx) * (1.0 - smoothstep(0.93, 1.0, l));
            vividSum += c * w;
            vividW += w;
        }
    }

    bool frameValid = meanN > 0.5;     // a loading screen has nothing in it and teaches nothing

    vec4 pCM = REG(0), pCA = REG(1), pSM = REG(2), pSA = REG(3), pGM = REG(4), pGA = REG(5);

    vec3 meanNow = frameValid ? meanSum / meanN : pCM.rgb;
    float conf = clamp(vividW / 2.0, 0.0, 1.0);       // trust the vivid average as far as there was any
    vec3 accentNow = frameValid ? mix(meanNow, vividSum / max(vividW, 0.0001), conf) : pCA.rgb;

    // ---- which place, and how far through it -------------------------------------------
    float tag = (mod(uEpoch, 200.0) + 1.0) / 255.0;
    bool fresh = pCM.a < 0.5 / 255.0 || abs(pCM.a - tag) > 0.5 / 255.0;
    float count = fresh ? 0.0 : floor(pCA.a * 255.0 + 0.5);
    bool sigTaken = !fresh && pGM.a > 0.5;
    bool restored = !fresh && pGA.a > 0.5;

    vec3 cm = pCM.rgb, ca = pCA.rgb, gm = pGM.rgb, ga = pGA.rgb;
    float newCount = count;

    // The first frames of a place may not be the place yet - the picture can still be filling
    // in. Track it through SKY_THEME_WARMUP frames without remembering any of it, then average
    // the next SKY_THEME_FRAMES.
    float WARMUP = float(SKY_THEME_WARMUP);
    float window = WARMUP + float(SKY_THEME_FRAMES);

#if SKY_THEME_LOCK
    bool capturing = count < window && !restored;
#else
    bool capturing = true;
#endif

    if (capturing && frameValid) {
        newCount = min(count + 1.0, 250.0);
        if (count < WARMUP) {
            cm = meanNow;
            ca = accentNow;
        } else {
            // A running average over the window, so each frame weighs the same.
            float rate = 1.0 / (count - WARMUP + 1.0);
#if !SKY_THEME_LOCK
            rate = max(rate, SKY_THEME_SPEED);
#endif
            cm = approach(cm, meanNow, rate);
            ca = approach(ca, accentNow, rate);
        }

#if SKY_THEME_LOCK && SKY_THEME_MEMORY
        // End of the warm-up: take this place's fingerprint, and see whether it has been
        // seen before this session.
        if (newCount >= WARMUP && !sigTaken) {
            gm = cm;
            ga = ca;
            sigTaken = true;

            float best = 1.0e9;
            vec3 foundM = cm;
            vec3 foundA = ca;
            for (int s = 0; s < 12; s++) {
                vec4 sm = MEMC(4 * s);
                vec4 sa = MEMC(4 * s + 1);
                if (sm.a > 0.99 && sa.a > 0.99) {
                    vec3 d1 = sm.rgb - gm;
                    vec3 d2 = sa.rgb - ga;
                    float d = dot(d1, d1) + dot(d2, d2);
                    if (d < best) {
                        best = d;
                        foundM = MEMC(4 * s + 2).rgb;
                        foundA = MEMC(4 * s + 3).rgb;
                    }
                }
            }
            // Within about 0.09 in colour of a place already seen: the same kind of place.
            if (best < 0.008) {
                cm = foundM;
                ca = foundA;
                restored = true;
                newCount = window;
            }
        }
#endif
    }

    // ---- what the sky is shown ---------------------------------------------------------
    vec3 sm = pSM.rgb;
    vec3 sa = pSA.rgb;
    if (pSM.a < 0.5) {              // first ever: a neutral, middling, mildly warm sky
        sm = vec3(0.30);
        sa = vec3(0.50);
    }

#if SKY_THEME_LOCK
    bool done = newCount >= window;
#else
    bool done = true;
#endif
    // Hold the last settled theme while the new one is still being worked out, then ease to
    // it. No part of the capture is ever on screen.
    if (done) {
        sm = approach(sm, cm, SKY_THEME_SPEED);
        sa = approach(sa, ca, SKY_THEME_SPEED);
    }

    // ---- write this pixel's region -----------------------------------------------------
    int region = int(floor(gl_TexCoord[0].s * 6.0));
    vec4 outv = vec4(cm, tag);
    if (region == 1) outv = vec4(ca, newCount / 255.0);
    else if (region == 2) outv = vec4(sm, 1.0);
    else if (region == 3) outv = vec4(sa, 1.0);
    else if (region == 4) outv = vec4(gm, sigTaken ? 1.0 : 0.0);
    else if (region == 5) outv = vec4(ga, restored ? 1.0 : 0.0);

    gl_FragColor = vec4(clamp(outv.rgb, 0.0, 1.0), outv.a);
}
