#version 120
// Pass 2 of 4: the across-screen half of the separable blur. Reads the raw shade buffer.
#include "lib/view.glsl"
#include "lib/blur.glsl"

void main ()
{
    gl_FragColor = bilateralBlur(colortex1, gl_TexCoord[0].st, vec2(1.0, 0.0));
}
