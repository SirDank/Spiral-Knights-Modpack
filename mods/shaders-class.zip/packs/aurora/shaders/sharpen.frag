#version 120
//
// Final pass: contrast adaptive sharpening (AMD FidelityFX CAS).
//
// This is the sharpening half of FSR, and the only half that is meaningful here. The
// upscaling half needs the scene rendered at a lower resolution than the display, and this
// engine sizes a render target from its texture rather than letting a pass choose - there
// is no render-resolution knob to turn.
//
// It is worth having on its own: the occlusion blur and the bloom both soften the image,
// and this puts the edge definition back without the halo a plain unsharp mask leaves.
//
// "Adaptive" is the important part. The sharpening amount is scaled per pixel by how much
// local headroom there is: an area already near white or near black gets sharpened less,
// because pushing it further would only clip. That is what stops the bright edges in this
// game's palette from ringing.
//
#include "lib/view.glsl"

void main ()
{
    vec2 uv = gl_TexCoord[0].st;

#if SHARPEN
    vec2 texel = uScreen.zw;

    // The cross neighbourhood: CAS deliberately ignores the diagonals.
    //      b
    //    d e f
    //      h
    vec3 e = texture2D(colortex7, uv).rgb;
    vec3 b = texture2D(colortex7, uv + vec2(0.0, -1.0) * texel).rgb;
    vec3 d = texture2D(colortex7, uv + vec2(-1.0, 0.0) * texel).rgb;
    vec3 f = texture2D(colortex7, uv + vec2(1.0,  0.0) * texel).rgb;
    vec3 h = texture2D(colortex7, uv + vec2(0.0,  1.0) * texel).rgb;

    vec3 mn = min(e, min(min(b, d), min(f, h)));
    vec3 mx = max(e, max(max(b, d), max(f, h)));

    // Headroom in both directions: how far this neighbourhood can be pushed before it
    // clips at either end. min(mn, 2-mx) is small wherever there is little room to move.
    vec3 amplitude = sqrt(clamp(min(mn, 2.0 - mx) / max(mx, 0.0001), 0.0, 1.0));

    // Back off wherever depth is not locally smooth.
    //
    // Two cases, both of which sharpening makes worse. Across a silhouette it produces a
    // halo. And Spiral Knights fades occluding walls out with screen-door transparency -
    // a one-pixel checkerboard alternating between the wall and whatever is behind it -
    // which is close to the worst possible input for a sharpener: it reads the dither as
    // detail and amplifies it into hard stripes that crawl as the camera moves.
    //
    // The checkerboard is detected by its signature rather than by raw depth variance:
    // in a dithered region a pixel matches its neighbour two along far better than the one
    // immediately beside it. Real geometry has no such pattern.
    float smoothness = depthGuard(uv);
    vec3 w = amplitude * (-SHARPNESS * 0.2 * smoothness);
    vec3 sharpened = (b * w + d * w + f * w + h * w + e) / (1.0 + 4.0 * w);

    gl_FragColor = vec4(clamp(sharpened, 0.0, 1.0), 1.0);
#else
    gl_FragColor = texture2D(colortex7, uv);
#endif
}
