#version 120
// Pass 3 of 4: the down-screen half. Reads what pass 2 wrote.
#include "lib/view.glsl"
#include "lib/blur.glsl"

void main ()
{
    gl_FragColor = bilateralBlur(colortex2, gl_TexCoord[0].st, vec2(0.0, 1.0));
}
