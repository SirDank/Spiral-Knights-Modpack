#version 120
// Wide bloom, across. Re-blurs the tight glow at a much larger spread to build the halo
// around it - far cheaper than one enormous kernel, since the input is already smooth.
#include "lib/color.glsl"
#include "lib/bloom.glsl"

void main ()
{
    gl_FragColor = vec4(bloomBlur(colortex6, gl_TexCoord[0].st, vec2(1.0, 0.0), BLOOM_WIDE_SCALE), 1.0);
}
