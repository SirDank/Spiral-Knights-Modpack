//
// sky.glsl - a sky, a sun, two layers of cloud, and a sea of cloud under the level.
//
// None of this exists in the scene. The pass runs after the scene is drawn and can only
// repaint pixels, and what makes that enough is that the sky in this game is exactly the
// pixels the depth buffer was never written to: "sky" is a test any pass can make, and a
// view ray through such a pixel has left the level without hitting anything.
//
// Everything is analytic. A volumetric march costs twenty-odd steps per pixel with a light
// march inside it; a layer of cloud is one noise lookup, one more towards the sun for its
// lighting, and looks right from underneath - which is how a player sees a sky.
//
// Requires: uInvProjection, uInvView, uCamera, uTime (and view.glsl, noise.glsl).
//

const vec3 UP = vec3(0.0, 0.0, 1.0);

/**
 * How bright the level is overall, 0..1; set once per pixel by renderSky() for the auto
 * style to read. A global because every helper that needs the time of day would otherwise
 * have to be handed it.
 */
float gLum = 0.30;

// ---- palette -----------------------------------------------------------------------------
//
// Three skies - noon, golden hour, night - mixed by where the sun is. Each has a colour
// overhead and a colour at the horizon; the sky is a blend between them that favours the
// horizon, because a horizontal line of sight crosses several times as much air as a
// vertical one and the extra scattering washes the blue out.

const vec3 ZEN_DAY   = vec3(0.14, 0.34, 0.78);
const vec3 HOR_DAY   = vec3(0.64, 0.80, 0.96);

const vec3 ZEN_DUSK  = vec3(0.13, 0.22, 0.52);
const vec3 HOR_DUSK_SUN  = vec3(0.98, 0.60, 0.30);   // the horizon under the sun
const vec3 HOR_DUSK_AWAY = vec3(0.62, 0.52, 0.74);   // and the far side: the belt of Venus

const vec3 ZEN_NIGHT = vec3(0.014, 0.028, 0.085);
const vec3 HOR_NIGHT = vec3(0.06, 0.09, 0.20);

// ---- the view ----------------------------------------------------------------------------

/** Horizontal part of the camera's forward vector, unit length. */
vec3 camFlat ()
{
    return normalize(vec3(-uInvView[2].xy, 0.0));
}

vec3 camRight ()
{
    return normalize(vec3(uInvView[0].xy, 0.0));
}

/**
 * The world-space direction the sky is looked at along, through this pixel.
 *
 * Not the camera's own ray. This camera looks down at about 45 degrees with a 60 degree
 * field, so the top of the screen is still 15 degrees BELOW the horizon: through the real
 * rays there is no sky to paint, only the ground and what lies under it. The ray is rotated
 * about the camera's right axis until the picture's own centre sits SKY_PITCH degrees off the
 * horizontal, which puts the horizon on screen and everything above it in the part of the
 * frame the level leaves empty. The yaw is untouched, so the sky still turns with the view.
 */
vec3 skyRay (vec2 uv)
{
    vec3 v = normalize(viewPosition(uv, 0.0));
    vec3 right = camRight();
    float p = radians(SKY_PITCH);
    vec3 fwd = camFlat() * cos(p) + UP * sin(p);
    vec3 up = cross(right, fwd);
    return normalize(right * v.x + up * v.y - fwd * v.z);
}

// ---- styles ------------------------------------------------------------------------------
//
// SKY_STYLE picks a ready-made sky. 0 leaves everything to the sliders; the others fix the
// sun, the cloud and the weather and ignore those sliders. The choice is a #define, so the
// table below is resolved when the shader compiles and costs nothing per pixel.
//
//   1 golden hour   2 noon   3 sunset   4 twilight   5 night   6 overcast   7 day cycle
//   8 auto: the level's own brightness sets the hour - dark dungeon, night sky

float styleElevation ()
{
#if SKY_STYLE == 0
    return SKY_SUN_ELEVATION;
#elif SKY_STYLE == 1
    return 9.0;
#elif SKY_STYLE == 2
    return 46.0;
#elif SKY_STYLE == 3
    return 1.5;
#elif SKY_STYLE == 4
    return -6.0;
#elif SKY_STYLE == 5
    return -32.0;
#elif SKY_STYLE == 6
    return 30.0;
#elif SKY_STYLE == 8
    // Mean brightness of the level, mapped to the sun's height: a pitch-dark dungeon is deep
    // night, a mid-bright one golden hour, a sunlit meadow noon. The ramp's ends sit where
    // this game's levels actually are rather than at 0 and 1: almost nothing averages above
    // 0.45, and the dark dungeons sit well under 0.1.
    return mix(-32.0, 40.0, smoothstep(0.06, 0.45, gLum)) + SKY_AUTO_SHIFT;
#else
    // One full day in SKY_CYCLE minutes: up to 53 degrees, down to 27 below.
    return 13.0 + 40.0 * sin(uTime / (max(SKY_CYCLE, 0.2) * 60.0) * 6.2831853);
#endif
}

float styleYaw ()
{
#if SKY_STYLE == 0 || SKY_STYLE == 7
    return SKY_SUN_YAW;
#elif SKY_STYLE == 1
    return -4.0;
#elif SKY_STYLE == 2
    return 14.0;
#elif SKY_STYLE == 3
    return -8.0;
#elif SKY_STYLE == 4
    return 0.0;
#elif SKY_STYLE == 5
    return 12.0;
#else
    return 10.0;
#endif
}

float styleCover ()
{
#if SKY_STYLE == 0 || SKY_STYLE == 7
    return SKY_CLOUD_COVER;
#elif SKY_STYLE == 2
    return 0.55;
#elif SKY_STYLE == 6
    return 0.30;
#else
    return 0.58;
#endif
}

float styleSoft ()
{
#if SKY_STYLE == 0 || SKY_STYLE == 7
    return SKY_CLOUD_SOFT;
#elif SKY_STYLE == 6
    return 0.55;
#else
    return 0.22;
#endif
}

/** 1 for the overcast style, else 0: flattens colour and hides the sun. */
float styleOvercast ()
{
#if SKY_STYLE == 6
    return 1.0;
#else
    return 0.0;
#endif
}

/**
 * Where the moon is: the sun's yaw, and as high as the sun is low. A moon opposite the sun,
 * as in the real sky, would be behind a camera that never turns round.
 */
vec3 moonDirection ()
{
    float yaw = radians(styleYaw());
    float el = radians(clamp(-styleElevation() * 0.6, 12.0, 26.0));
    vec3 heading = camFlat() * cos(yaw) + camRight() * sin(yaw);
    return normalize(heading * cos(el) + UP * sin(el));
}

/**
 * Where the sun is. Placed relative to the view, not the world: the camera here has a fixed
 * yaw, and a sun at some arbitrary compass bearing is as likely to be behind it as in shot.
 */
vec3 sunDirection ()
{
    float yaw = radians(styleYaw());
    float el = radians(styleElevation());
    vec3 heading = camFlat() * cos(yaw) + camRight() * sin(yaw);
    return normalize(heading * cos(el) + UP * sin(el));
}

/**
 * How golden and how dark the hour is, from the sun's height.
 * x = dusk (warm light, 1 around the horizon), y = night.
 */
vec2 hour (float sunZ)
{
    float dusk = (1.0 - smoothstep(0.08, 0.50, sunZ)) * smoothstep(-0.30, -0.02, sunZ);
    float night = 1.0 - smoothstep(-0.30, -0.05, sunZ);
    return vec2(dusk, night);
}

vec3 sunTint (float dusk)
{
    return mix(vec3(1.0, 0.97, 0.88), vec3(1.0, 0.62, 0.30), dusk);
}

/**
 * How strongly the sun's colour reaches a cloud: all of it on the side of the sky the sun
 * is in, much less on the far side, where cloud is lit by sky and goes pink and grey.
 */
float warmth (float ts, float dusk)
{
    float facing = clamp(ts * 0.5 + 0.5, 0.0, 1.0);
    return clamp(0.22 + dusk * mix(0.15, 0.85, facing * facing), 0.0, 1.0);
}

/**
 * Which way the wind blows, as a unit vector in the world's XY plane.
 *
 * Measured from the view, not from a compass bearing: degrees clockwise from screen-right.
 * Streaks of cirrus drawn along a world axis meet the horizon at a point and fan out of it
 * like a speed effect; drawn across the view they run parallel to the horizon and read as
 * wisps. The camera's yaw is fixed in this game, so this is as stable as a bearing.
 */
vec2 windDir (float extraDegrees)
{
    float a = radians(SKY_WIND_DIR + extraDegrees);
    return camRight().xy * cos(a) + camFlat().xy * sin(a);
}

vec2 windVec ()
{
    return windDir(0.0) * (SKY_WIND * uTime);
}


// ---- the empty sky -----------------------------------------------------------------------

/** Gradient and the sun's glow: the sky with nothing in it. */
vec3 skyBase (vec3 ray, vec3 sun, float dusk, float night, vec3 theme)
{
    float ts = dot(ray, sun);
    float facing = clamp(ts * 0.5 + 0.5, 0.0, 1.0);

    float k = pow(1.0 - clamp(ray.z, 0.0, 1.0), SKY_HORIZON_FALL);

    // The level's own colour, as an accent: the strongest channel normalised to 1 so a dark
    // theme still tints, and how much it tints scales with how colourful it is - a grey
    // level leaves the sky alone, a red one turns the horizon red.
    float tmx = max(theme.r, max(theme.g, theme.b));
    float tmn = min(theme.r, min(theme.g, theme.b));
    float tk = SKY_THEME * smoothstep(0.08, 0.40, (tmx - tmn) / max(tmx, 0.001));
    vec3 accent = clamp((theme - tmn * 0.5) / max(tmx - tmn * 0.5, 0.001), 0.0, 1.0);

    vec3 zen = mix(mix(ZEN_DAY, ZEN_DUSK, dusk), ZEN_NIGHT + accent * 0.14 * tk, night);
    // Overhead the tint is a deep, dark version of the accent mixed into the blue.
    zen = mix(zen, accent * 0.30 + vec3(0.02, 0.03, 0.09), 0.45 * tk * (1.0 - night));

    vec3 horDay = mix(HOR_DAY, mix(vec3(0.82, 0.86, 0.92), accent, 0.65) * 0.95, 0.50 * tk);
    vec3 horSun = mix(HOR_DUSK_SUN, accent * vec3(1.0, 0.90, 0.78), 0.60 * tk);
    vec3 horAway = mix(HOR_DUSK_AWAY, accent * 0.72 + vec3(0.12, 0.10, 0.16), 0.55 * tk);

    vec3 horDusk = mix(horAway, horSun, pow(facing, 2.5));
    vec3 hor = mix(mix(horDay, horDusk, dusk), HOR_NIGHT + accent * 0.30 * tk, night);
    // At noon the horizon is still brighter on the sun's side; just not coloured.
    hor += vec3(0.16, 0.13, 0.07) * pow(max(ts, 0.0), 3.0) * (1.0 - dusk) * (1.0 - night);

    vec3 c = mix(zen, hor, k);

    // Light scattered out of the sun's beam: a wide soft shoulder and a tight bright core.
    float t0 = max(ts, 0.0);
    float glow = pow(t0, 5.0) * 0.20 + pow(t0, 36.0) * 0.40;
    c += sunTint(dusk) * glow * SKY_GLOW * (1.0 - night);
    return c;
}

/** Stars, for when the sun is down. */
float stars (vec3 ray, float night)
{
    if (night < 0.01 || ray.z < 0.0) return 0.0;
    vec3 p = ray * 110.0;
    vec3 id = floor(p);
    vec3 h = hash33(id);
    vec3 f = fract(p) - 0.5;
    float d = length(f - (h - 0.5) * 0.6);
    // A few stars bigger and brighter than the rest; they are what the eye counts.
    float size = mix(0.14, 0.30, h.z * h.z);
    float star = smoothstep(size, 0.0, d) * step(0.90, h.x) * (0.55 + 0.9 * h.z);
    float twinkle = 0.75 + 0.25 * sin(uTime * 3.0 + h.y * 40.0);
    return star * twinkle * night * smoothstep(0.0, 0.12, ray.z);
}

// ---- clouds ------------------------------------------------------------------------------

/**
 * The cloud layer overhead, as colour with coverage in alpha.
 *
 * The layer is a plane CLOUD_HEIGHT above the camera, hit by perspective, so clouds shrink
 * towards the horizon the way real ones do. It is measured from the camera and not from
 * the level's own zero because nothing tells this pass what altitude a level was built at.
 *
 * Lit from one extra noise sample taken a step towards the sun. If the field is higher here
 * than there, this point is on the sun-facing flank of a mass of cloud; if lower, it is
 * round the back of one. A single difference gives the whole bumpy, sun-lit relief.
 */
vec4 cumulus (vec3 ray, vec3 sun, float dusk, float night, vec3 horizon)
{
    if (ray.z < 0.012) return vec4(0.0);

    float tn = 1.0 / (ray.z + 0.05);                   // distance, in layer heights
    vec2 p = (uCamera.xy + ray.xy * (SKY_CLOUD_HEIGHT * tn) + windVec()) * SKY_CLOUD_SCALE;

    // Warp the lookup with a coarse field first. Billowy, rolling edges rather than the
    // clean contours of plain noise.
    vec2 warp = vec2(fbm3(p * 0.45 + 7.3), fbm3(p * 0.45 - 3.1)) - 0.5;
    vec2 q = p + warp * 1.1;

    float far = smoothstep(4.0, 12.0, tn);             // soften what is far away,
    float soft = min(1.0, styleSoft() + far * 0.35); // or it aliases into static
    float n = fbm(q);
    float cov = smoothstep(styleCover(), styleCover() + soft, n);
    if (cov < 0.002) return vec4(0.0);

    float nSun = fbm(q + sun.xy * 0.22);
    float lit = clamp(0.55 + (n - nSun) * 4.2, 0.0, 1.0);
    lit *= 1.0 - 0.30 * smoothstep(0.62, 0.95, n);     // the thick core stays dimmer

    float ts = dot(ray, sun);
    vec3 tint = sunTint(dusk);
    vec3 sunlit = mix(vec3(1.0, 0.99, 0.96), tint, warmth(ts, dusk));
    // Shade is lit by the sky, not the sun, so it takes the sky's colour.
    vec3 shade = mix(vec3(0.52, 0.62, 0.84), vec3(0.44, 0.38, 0.58), dusk);
    shade = mix(shade, horizon * 0.9, 0.2);

    vec3 col = mix(shade, sunlit, lit);

    // The silver lining: thin edges between the viewer and the sun let light through.
    float edge = cov * (1.0 - cov) * 4.0;
    col += tint * edge * pow(max(ts, 0.0), 4.0) * 0.55 * SKY_GLOW;
    // And right round the sun even the body of a cloud lights up from behind.
    col += tint * (1.0 - cov * 0.6) * pow(max(ts, 0.0), 10.0) * 0.45 * SKY_GLOW;

    col *= mix(1.0, 0.07, night);
    col = mix(col, col * vec3(0.55, 0.7, 1.2), night);
    // The level's own light on the underside of the cloud, which is most of what lights a night one.
    col += horizon * 0.55 * night * (0.35 + 0.65 * lit);
    // Moonlit: night cloud is lit from the moon's side.
    col += vec3(0.30, 0.36, 0.55) * night * (0.15 + 0.85 * lit) * (0.35 + 0.65 * pow(max(dot(ray, moonDirection()), 0.0), 5.0));

    float fade = 1.0 - smoothstep(9.0, 17.0, tn);
    return vec4(col, cov * fade * SKY_CLOUD_OPACITY);
}

/**
 * Thin high streaks. Noise stretched hard along the wind, so it reads as the wisps in a
 * sunset photograph rather than as another round cloud.
 */
vec4 cirrus (vec3 ray, vec3 sun, float dusk, float night)
{
    if (SKY_CIRRUS <= 0.001 || ray.z < 0.03 || styleOvercast() > 0.5) return vec4(0.0);

    float t = (SKY_CLOUD_HEIGHT * 2.4) / (ray.z + 0.09);
    vec2 p = uCamera.xy * 0.3 + ray.xy * t + windVec() * 1.7;

    vec2 along = windDir(8.0);
    vec2 across = vec2(-along.y, along.x);
    vec2 q = vec2(dot(p, along) * 0.00085, dot(p, across) * 0.0030);

    float n = fbm3(q + vec2(3.1, 7.7));
    float n2 = fbm3(q * vec2(2.1, 2.6) + n * 1.6);
    float streak = smoothstep(0.40, 0.76, 0.55 * n + 0.55 * n2);

    float ts = dot(ray, sun);
    vec3 tint = sunTint(dusk);
    vec3 col = mix(vec3(0.95, 0.95, 1.0), tint, warmth(ts, dusk));
    // Far from the sun, dusk cirrus is a dim pinkish grey; beside it, it is the brightest
    // thing in the sky.
    col *= mix(0.62, 1.0, clamp(ts * 0.5 + 0.5, 0.0, 1.0)) * (0.85 + 0.55 * pow(max(ts, 0.0), 3.0));
    col *= mix(1.0, 0.08, night);

    return vec4(col, streak * 0.62 * SKY_CIRRUS * smoothstep(0.03, 0.22, ray.z));
}

/**
 * The cloud floor beneath the level.
 *
 * Below the horizon there is no sky, and for this camera that is most of the screen. A level
 * that floats gets a sea of cloud to float on: a plane SKY_SEA_DEPTH under the camera, hit by
 * perspective, so as the camera pans the cloud slides underneath at the right rate and the
 * level has height. Haze takes it to the horizon colour with distance, which is also what
 * hides the aliasing of noise sampled across a few hundred layer-widths.
 */
vec3 cloudSea (vec3 ray, vec3 sun, float dusk, float night, vec3 horizon)
{
    float t = SKY_SEA_DEPTH / max(-ray.z, 0.004);
    vec2 p = (uCamera.xy + ray.xy * t + windVec() * 0.6) * SKY_SEA_SCALE;

    float n = fbm(p);
    float nSun = fbm(p + sun.xy * 0.16);
    float cov = smoothstep(SKY_SEA_COVER, SKY_SEA_COVER + 0.28, n);
    float lit = clamp(0.60 + (n - nSun) * 3.6, 0.0, 1.0);

    vec3 tint = sunTint(dusk);
    vec3 sunlit = mix(vec3(1.0, 0.99, 0.97), tint, warmth(dot(ray, sun), dusk));
    vec3 shade = mix(vec3(0.55, 0.64, 0.84), vec3(0.46, 0.40, 0.60), dusk);
    vec3 top = mix(shade, sunlit, lit);

    // Where the sea has gaps you see down a long way, through a lot of air.
    vec3 deep = mix(horizon * 0.80, vec3(0.30, 0.44, 0.70), 0.55);

    vec3 col = mix(deep, top, cov);
    col *= mix(1.0, 0.07, night);
    col = mix(col, col * vec3(0.55, 0.7, 1.2), night);

    float haze = 1.0 - exp(-t / SKY_SEA_HAZE);
    return mix(col, horizon, haze);
}

// ---- the whole picture -------------------------------------------------------------------

/** Everything the sky is, along one ray. */
vec3 renderSky (vec3 ray, vec3 theme, float lum)
{
    gLum = lum;
    vec3 sun = sunDirection();
    vec2 hr = hour(sun.z);
    float dusk = hr.x, night = hr.y;

    vec3 sky = skyBase(ray, sun, dusk, night, theme);

    // The colour of the horizon in this direction: what everything far away fades into.
    vec3 horizon = skyBase(normalize(vec3(ray.xy, 0.0001)), sun, dusk, night, theme);

    // Nothing but the sun itself may reach full white: a bright cloud at 1.0 would pass the
    // bloom threshold and the whole sky would glow. So the sky is held under that first.
    float pk = max(sky.r, max(sky.g, sky.b));
    if (pk > 0.96) sky *= 0.96 / pk;

    // The disc, sized in degrees, with a soft rim; a hard edge aliases against a moving
    // camera at any resolution. Painted BEFORE the clouds, so a cloud in front of the sun
    // covers it in proportion to how much cloud there is: thin cloud shows it through, thick
    // cloud hides it, and the edges of the cloud glow where the sun is behind them.
    vec3 tint = sunTint(dusk);
    float ang = acos(clamp(dot(ray, sun), -1.0, 1.0));
    float r = radians(max(SKY_SUN_SIZE, 0.05));
    float disc = 1.0 - smoothstep(r * 0.82, r, ang);
    float corona = 1.0 - smoothstep(r, r * 3.2, ang);
    float ov = styleOvercast();
    float visible = smoothstep(-0.03, 0.01, ray.z) * (1.0 - night) * (1.0 - ov * 0.9);
    sky += tint * corona * corona * 0.22 * SKY_GLOW * visible;
    sky = mix(sky, mix(tint, vec3(1.0), 0.65), disc * visible);

    // The moon, by night: a pale disc with faint seas on it and a cold halo.
    if (night > 0.02) {
        vec3 moon = moonDirection();
        float md = dot(ray, moon);
        float mr = radians(2.3);
        float mang = acos(clamp(md, -1.0, 1.0));
        float mvis = night * smoothstep(-0.02, 0.03, ray.z);
        vec2 mp = vec2(dot(ray - moon, camRight()), dot(ray - moon, normalize(cross(camRight(), camFlat())))) / mr;
        float seas = 0.84 + 0.16 * fbm3(mp * 1.6 + 3.0);
        sky += vec3(0.50, 0.60, 0.95) * (pow(max(md, 0.0), 90.0) * 0.45 + pow(max(md, 0.0), 14.0) * 0.07) * mvis;
        sky = mix(sky, vec3(0.88, 0.92, 1.0) * seas, (1.0 - smoothstep(mr * 0.88, mr, mang)) * mvis);
    }

    if (ray.z > -0.01) {
#if STARS
        sky += vec3(0.85, 0.9, 1.0) * stars(ray, night);
#endif
        vec4 ci = cirrus(ray, sun, dusk, night);
        sky = mix(sky, ci.rgb, ci.a);

#if SKY_CLOUDS
        vec4 cl = cumulus(ray, sun, dusk, night, horizon);
        sky = mix(sky, cl.rgb, cl.a);
#endif
    }

    // Below the horizon: the cloud sea, or just thickening air.
    if (ray.z < 0.006) {
#if SKY_SEA
        vec3 sea = cloudSea(ray, sun, dusk, night, horizon);
        sky = mix(sky, sea, smoothstep(0.006, -0.006, ray.z));
#else
        sky = mix(sky, horizon * 0.82, smoothstep(0.0, -0.5, ray.z));
#endif
    }

    // Overcast: the colour drained to a bright grey, and a little of the theme kept.
    if (ov > 0.0) {
        float l = dot(sky, LUMA);
        sky = mix(sky, vec3(l) * 0.93 + vec3(0.03, 0.04, 0.06), 0.80 * ov);
    }
    return sky;
}
