//
// Value noise and the sum of a few octaves of it, for the sky.
//
// Not gradient (Perlin) noise: that needs a random vector and a dot product per corner, four
// times the arithmetic across a full-screen pass, for a difference nobody can see through a
// cloud. Value noise's weakness is a faint axis-aligned grid, and the rotation between
// octaves in fbm() is what breaks that up.
//

/**
 * Hash without sin().
 *
 * The sin-based one-liner everybody copies loses its low bits once its argument gets large,
 * and a sky that drifts for an hour drives the coordinates a long way. This one is pure
 * fract/multiply-add, so it is as good at the thousandth second as the first.
 */
float hash21 (vec2 p)
{
    vec3 p3 = fract(vec3(p.xyx) * 0.1031);
    p3 += dot(p3, p3.yzx + 33.33);
    return fract((p3.x + p3.y) * p3.z);
}

vec3 hash33 (vec3 p)
{
    p = fract(p * vec3(0.1031, 0.1030, 0.0973));
    p += dot(p, p.yxz + 33.33);
    return fract((p.xxy + p.yxx) * p.zyx);
}

float valueNoise (vec2 p)
{
    vec2 i = floor(p);
    vec2 f = fract(p);

    // Quintic, not smoothstep: its second derivative is zero at the lattice points too, so a
    // slowly drifting cloud does not show a faint crease each time it crosses one.
    vec2 u = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);

    float a = hash21(i);
    float b = hash21(i + vec2(1.0, 0.0));
    float c = hash21(i + vec2(0.0, 1.0));
    float d = hash21(i + vec2(1.0, 1.0));

    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

/**
 * Octaves of value noise, each finer and fainter than the last, each rotated.
 *
 * Doubling the frequency alone leaves every octave on the same lattice directions, and they
 * reinforce into visible horizontal and vertical streaks; half a radian per octave means no
 * two lattices line up.
 */
float fbm (vec2 p)
{
    const mat2 R = mat2(0.87758, -0.47943, 0.47943, 0.87758);

    float sum = 0.0;
    float amplitude = 0.5;
    float total = 0.0;

    // SKY_OCTAVES is a #define so the bound is a compile-time constant, which GLSL 120 wants
    // of a loop.
    for (int i = 0; i < SKY_OCTAVES; i++) {
        sum += valueNoise(p) * amplitude;
        total += amplitude;
        p = R * p * 2.0;
        amplitude *= 0.5;
    }

    return sum / max(total, 0.0001);
}

/** Three octaves, always: for the layers that are only texture on top of something else. */
float fbm3 (vec2 p)
{
    const mat2 R = mat2(0.87758, -0.47943, 0.47943, 0.87758);
    float sum = valueNoise(p) * 0.5;
    p = R * p * 2.0;
    sum += valueNoise(p) * 0.25;
    p = R * p * 2.0;
    sum += valueNoise(p) * 0.125;
    return sum / 0.875;
}
