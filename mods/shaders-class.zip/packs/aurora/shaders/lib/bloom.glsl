//
// A plain separable gaussian, for bloom only.
//
// Deliberately *not* the bilateral blur used for occlusion. That one rejects taps across a
// depth discontinuity, which is right for shadows - they must not leak past a silhouette -
// and exactly wrong for bloom, whose whole purpose is to spill light past the edge of the
// object emitting it.
//
// The taps are spread wider than one texel apiece (BLOOM_SCALE). Buffers are sampled with
// linear filtering, so each tap already averages the texels it lands between: a wide, cheap
// kernel rather than a narrow, expensive one.
//
vec3 bloomBlur (sampler2D src, vec2 uv, vec2 axis, float spread)
{
    vec2 step = axis * (uScreen.zw / PASS_SCALE) * spread;

    vec3 sum = texture2D(src, uv).rgb;
    float total = 1.0;

    for (int i = 1; i <= BLOOM_RADIUS; i++) {
        float fi = float(i);
        float w = exp(-fi * fi / (2.0 * float(BLOOM_RADIUS) * float(BLOOM_RADIUS) * 0.33));

        for (int s = -1; s <= 1; s += 2) {
            vec2 at = uv + step * fi * float(s);
            // No onScreen() test: clamped sampling at the border is what lets a light at
            // the edge of the screen still bloom inward instead of cutting off.
            sum += texture2D(src, at).rgb * w;
            total += w;
        }
    }
    return sum / total;
}
