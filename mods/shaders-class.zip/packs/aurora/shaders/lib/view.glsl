//
// view.glsl - turning a depth sample back into geometry.
//
// Assumes the loader has declared `depthtex0`, `uProjection`, `uInvProjection`, `uScreen`,
// `uNear` and `uFar` for the pass including this (from its `samplers` and `sceneUniforms`).
//
// Conventions: `uv` is [0,1] across the screen; view space is right-handed with the eye at
// the origin looking down -Z, so a visible surface has a *negative* z and "nearer the
// camera" means a *larger* z.
//
// A note on cost, because it dominates the design here. Every helper below is called per
// pixel across several full-screen passes, and a dependent texture fetch is the expensive
// part - not the arithmetic. An earlier version had separate functions for the normal, the
// silhouette test, the dither test and the grazing-angle test, each fetching the same
// neighbourhood independently, and the guards alone cost more than the effects they were
// guarding. They are one function now: fetch the neighbours once, answer every question
// from those samples.
//
#include "color.glsl"

/** Raw window-space depth [0,1] at a screen position. */
float depthAt (vec2 uv)
{
    return texture2D(depthtex0, uv).r;
}

/** Window-space depth -> view-space position. */
vec3 viewPosition (vec2 uv, float depth)
{
    vec4 clip = vec4(uv * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
    vec4 view = uInvProjection * clip;
    return view.xyz / view.w;
}

/** The view-space position of whatever the scene drew at this pixel. */
vec3 scenePosition (vec2 uv)
{
    return viewPosition(uv, depthAt(uv));
}

/**
 * View-space position -> screen. Returns (u, v, depth); the caller is expected to reject
 * results outside [0,1] rather than sample off-screen.
 */
vec3 project (vec3 viewPos)
{
    vec4 clip = uProjection * vec4(viewPos, 1.0);
    vec3 ndc = clip.xyz / clip.w;
    return vec3(ndc.xy * 0.5 + 0.5, ndc.z * 0.5 + 0.5);
}

bool onScreen (vec2 uv)
{
    return uv.x >= 0.0 && uv.x <= 1.0 && uv.y >= 0.0 && uv.y <= 1.0;
}

/** Window depth -> distance from the eye in world units. */
float linearDepth (float d, float near, float far)
{
    float ndc = d * 2.0 - 1.0;
    return (2.0 * near * far) / (far + near - ndc * (far - near));
}

/**
 * Interleaved gradient noise, for sampling offsets.
 *
 * Its values cover 0..1 evenly over any small neighbourhood, which is what lets a blur
 * average them away; white noise blurs to mush instead.
 */
float ign (vec2 p)
{
    return fract(52.9829189 * fract(dot(p, vec2(0.06711056, 0.00583715))));
}

/**
 * The normal and a confidence value, from one read of the neighbourhood.
 *
 * Seven depth samples answer four questions that used to cost thirty-three between them:
 *
 *  - the NORMAL, from the neighbour on each axis that is closer in depth. Not dFdx/dFdy:
 *    those are evaluated per 2x2 quad, so at a silhouette the derivative spans two surfaces
 *    metres apart and the normal points nowhere real - which draws a hard dark rim around
 *    every object. Taking the nearer side keeps the reconstruction on one surface.
 *
 *  - the SILHOUETTE test, from how far the neighbours sit in depth. Across an edge the
 *    gather is reading another object, so whatever it returns is guesswork, and guesswork
 *    lands dark.
 *
 *  - the DITHER test. Spiral Knights fades occluding walls out with screen-door
 *    transparency - a one-pixel checkerboard between the wall and what is behind it - and
 *    depth there alternates between two distant surfaces, which every depth-based effect
 *    reads as violently detailed geometry. Identified by its signature rather than by
 *    variance: in a dithered region a pixel matches its neighbour TWO along much better
 *    than the one beside it, which real geometry never does.
 *
 *  - the GRAZING test. On a surface nearly edge-on, one pixel covers a great deal of depth,
 *    the taps land far apart in world space, and the normal is mostly noise - so anything
 *    keyed off it flickers as the camera drifts.
 *
 * `guard` is 1 where screen space can answer honestly and 0 where it cannot.
 */
void surfaceInfo (vec2 uv, vec3 p, out vec3 n, out float guard)
{
    vec2 t = uScreen.zw;

    float d0  = depthAt(uv);
    float dl  = depthAt(uv - vec2(t.x, 0.0));
    float dr  = depthAt(uv + vec2(t.x, 0.0));
    float dd  = depthAt(uv - vec2(0.0, t.y));
    float du  = depthAt(uv + vec2(0.0, t.y));
    float dr2 = depthAt(uv + vec2(t.x * 2.0, 0.0));
    float du2 = depthAt(uv + vec2(0.0, t.y * 2.0));

    vec3 pl = viewPosition(uv - vec2(t.x, 0.0), dl);
    vec3 pr = viewPosition(uv + vec2(t.x, 0.0), dr);
    vec3 pd = viewPosition(uv - vec2(0.0, t.y), dd);
    vec3 pu = viewPosition(uv + vec2(0.0, t.y), du);

    vec3 dx = abs(pl.z - p.z) < abs(pr.z - p.z) ? (p - pl) : (pr - p);
    vec3 dy = abs(pd.z - p.z) < abs(pu.z - p.z) ? (p - pd) : (pu - p);

    n = normalize(cross(dx, dy));
    // Orient towards the eye, not by n.z: on a steeply angled surface n.z sits near zero
    // and the smallest wobble flips the sign, and the shading with it, frame to frame.
    vec3 toEye = -normalize(p);
    n = dot(n, toEye) < 0.0 ? -n : n;

    float here = abs(p.z);
    float spread = max(max(abs(pl.z - p.z), abs(pr.z - p.z)),
                       max(abs(pd.z - p.z), abs(pu.z - p.z)));
    float edge = 1.0 - smoothstep(0.01 * here, 0.06 * here, spread);

    float alternation = max(abs(d0 - dr) - abs(d0 - dr2),
                            abs(d0 - du) - abs(d0 - du2));
    float dither = clamp(alternation * 600.0, 0.0, 1.0);

    float grazing = smoothstep(0.12, 0.40, dot(n, toEye));

    guard = edge * (1.0 - dither) * grazing;
}

/**
 * The confidence half alone, for passes that never need a normal.
 *
 * Three samples rather than seven: the sharpener only has to know whether this pixel sits
 * on a continuous surface, and it does not care which way that surface faces.
 */
float depthGuard (vec2 uv)
{
    vec2 t = uScreen.zw;

    float d0  = depthAt(uv);
    float dr  = depthAt(uv + vec2(t.x, 0.0));
    float dr2 = depthAt(uv + vec2(t.x * 2.0, 0.0));

    float z0 = linearDepth(d0, uNear, uFar);
    float zr = linearDepth(dr, uNear, uFar);

    float edge = 1.0 - smoothstep(0.01 * z0, 0.06 * z0, abs(zr - z0));
    float dither = clamp((abs(d0 - dr) - abs(d0 - dr2)) * 600.0, 0.0, 1.0);

    return edge * (1.0 - dither);
}
