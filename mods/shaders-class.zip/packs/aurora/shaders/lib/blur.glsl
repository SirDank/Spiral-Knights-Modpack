//
// The shared body of the two blur passes.
//
// Taken as a sampler parameter so the horizontal and vertical passes can read different
// buffers (they must: a pass cannot read the buffer it writes) while sharing one
// implementation. GLSL 120 allows a sampler as a function parameter so long as the
// argument is a sampler variable rather than an expression.
//
// Bilateral: taps fade out with distance in *depth*, not only on screen. A plain blur
// would smear the shadow under a knight out across the ground behind it.
//
vec4 bilateralBlur (sampler2D src, vec2 uv, vec2 axis)
{
    vec2 step = axis * (uScreen.zw / PASS_SCALE) * BLUR_SCALE;
    float centre = linearDepth(depthAt(uv), uNear, uFar);

    vec4 sum = texture2D(src, uv);
    float total = 1.0;

    for (int i = 1; i <= BLUR_RADIUS; i++) {
        float fi = float(i);
        float w = exp(-fi * fi / (2.0 * float(BLUR_RADIUS) * float(BLUR_RADIUS) * 0.35));

        for (int s = -1; s <= 1; s += 2) {
            vec2 at = uv + step * fi * float(s);
            if (!onScreen(at)) continue;

            float d = linearDepth(depthAt(at), uNear, uFar);
            float dw = max(0.0, 1.0 - abs(d - centre) * BLUR_DEPTH_REJECT);

            sum += texture2D(src, at) * (w * dw);
            total += w * dw;
        }
    }
    return sum / total;
}
