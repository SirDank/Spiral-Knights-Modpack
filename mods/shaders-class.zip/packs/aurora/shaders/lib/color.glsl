//
// Colour helpers with no dependency on the depth buffer.
//
// Split out of view.glsl so the bloom passes can include it: they never sample depth, and
// including view.glsl would drag in functions referencing depthtex0, which those passes do
// not bind - an undeclared identifier at compile time.
//
/** Rec. 709 luminance weights: each channel's share of perceived brightness. */
const vec3 LUMA = vec3(0.2126, 0.7152, 0.0722);
