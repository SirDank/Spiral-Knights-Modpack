#version 120
//
// Bloom pass 1: isolate what is bright enough to spill.
//
// A hard threshold makes bloom pop on and off as a light drifts across it, which reads as
// flicker. The soft knee ramps contribution in quadratically over a band below the
// threshold instead, so a light brightening into range fades in.
//
#include "lib/color.glsl"

void main ()
{
    vec3 c = texture2D(colortex0, gl_TexCoord[0].st).rgb;

    // Brightness for the purposes of "should this glow", which is not the same question as
    // "how bright does this look".
    //
    // Rec. 709 luminance weights green at 0.72 and red at 0.21, because that is how the eye
    // responds. But a saturated projectile - orange, red, magenta - puts most of its energy
    // in the channels that weighting discounts: a vivid orange scores 0.61 luminance while
    // its red channel is already clipped at 1.0. Judged on luminance alone the brightest,
    // most obviously emissive things in the game never reach the threshold, while flat pale
    // surfaces sail past it.
    //
    // Mixing in the strongest channel fixes that. A dull grey surface has max == luma and is
    // unaffected; anything saturated is scored on the channel actually doing the work.
    float mx = max(c.r, max(c.g, c.b));
    float mn = min(c.r, min(c.g, c.b));
    float l = mix(dot(c, LUMA), mx, BLOOM_COLOR_BIAS);

    // Saturation decides which threshold applies.
    //
    // Brightness alone cannot tell an emissive projectile from pale marble: Haven's
    // fountain scored 0.92 against the orange bolt's 0.90, so any threshold low enough to
    // make projectiles glow made every pale surface glow harder, and the fountain blew out
    // to white. They differ in saturation, not brightness. A glowing thing is a colour; a
    // lit stone surface is a bright neutral.
    //
    // So a saturated colour is judged against BLOOM_THRESHOLD and a neutral one against
    // BLOOM_THRESHOLD_NEUTRAL, which sits far higher - a white surface has to be nearly
    // blown out in the source art before it is treated as a light.
    float saturation = (mx - mn) / max(mx, 0.0001);
    float threshold = mix(BLOOM_THRESHOLD_NEUTRAL, BLOOM_THRESHOLD,
                          smoothstep(0.15, 0.50, saturation));

    // How much of this pixel glows.
    //
    // The textbook bright pass extracts the excess ABOVE the threshold - (l - T) - which
    // assumes an HDR pipeline where a light source might sit at 4.0 and have plenty of
    // excess to give. Here the buffer is 8-bit and nothing exceeds 1.0, so subtracting a
    // 0.75 threshold left a vivid projectile contributing a fifth of its colour, and a grey
    // wall a fifteenth: too little to see once spread across a wide blur, and too little
    // separation between them to raise the strength without the whole scene hazing over.
    //
    // Normalising against the range that actually remains (1 - T) restores the dynamic
    // range, and the curve supplies the separation: something just over the line
    // contributes almost nothing, something near white contributes nearly all of itself.
    float over = max(0.0, l - threshold) / max(0.0001, 1.0 - threshold);
    float energy = pow(over, BLOOM_CURVE);

    // Scale the colour, not the luminance, so the glow keeps the light's hue.
    gl_FragColor = vec4(c * energy, 1.0);
}
