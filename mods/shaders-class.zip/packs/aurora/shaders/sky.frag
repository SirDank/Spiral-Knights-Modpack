#version 120
//
// Pass 1 of 11: repaint the sky.
//
// Runs first, ahead of everything else, so the sky is part of the picture the later passes
// work from: the bloom pass sees the sun, the grade covers the sky with the rest of the
// frame. A pixel the scene never wrote to is sky and gets painted; a pixel with geometry on
// it is copied through untouched.
//
// By default only a sky that is already BLUE is replaced. Levels with a backdrop of their
// own - the furnace glow under the Firestorm Citadel, the dark of a tunnel, Haven's grey -
// are part of that level's look, and a clear afternoon behind them is wrong in every one.
// SKY_ALWAYS replaces them anyway.
//
#include "lib/view.glsl"
#include "lib/noise.glsl"
#include "lib/sky.glsl"

/** How like the old, blue backdrop this colour is: 1 for a clear sky, 0 for anything else. */
float skyness (vec3 c)
{
    // Blue and bright. The ramps are wide because the backdrop's own colour varies with the
    // level's lighting.
    return smoothstep(0.06, 0.22, c.b - c.r) * smoothstep(0.35, 0.60, c.b);
}

void main ()
{
    vec2 uv = gl_TexCoord[0].st;
    vec4 base = texture2D(scene, uv);

#if !SKY
    gl_FragColor = base;
    return;
#endif

    float w = SKY_STRENGTH;

    if (depthAt(uv) < 0.9999) {
#if SKY_EDGE
        // The rim of a silhouette is a blend of the object and the old sky, written with the
        // object's depth, so it is not sky by the depth test and keeps a fringe of the old
        // backdrop round every cliff against the new sky. A pixel that touches sky and is
        // nearly the colour of that sky is the fringe; take it over. Compared against the
        // neighbouring sky pixel itself rather than any fixed colour, because the backdrop
        // is whatever the level (or a skybox mod) made it.
        vec2 t = uScreen.zw;
        vec2 o0 = vec2(t.x, 0.0);
        vec2 o1 = vec2(0.0, t.y);
        float near = 0.0;
        vec3 skyOld = vec3(0.0);
        if (depthAt(uv + o0) >= 0.9999)      { near = 1.0; skyOld = texture2D(scene, uv + o0).rgb; }
        else if (depthAt(uv - o0) >= 0.9999) { near = 1.0; skyOld = texture2D(scene, uv - o0).rgb; }
        else if (depthAt(uv + o1) >= 0.9999) { near = 1.0; skyOld = texture2D(scene, uv + o1).rgb; }
        else if (depthAt(uv - o1) >= 0.9999) { near = 1.0; skyOld = texture2D(scene, uv - o1).rgb; }
        if (near < 0.5) {
            gl_FragColor = base;
            return;
        }
        w *= 1.0 - smoothstep(0.04, 0.22, distance(base.rgb, skyOld));
#else
        gl_FragColor = base;
        return;
#endif
    } else {
#if !SKY_ALWAYS
        w *= skyness(base.rgb);
#endif
    }
    if (w <= 0.001) {
        gl_FragColor = base;
        return;
    }

    // What the level is like, as theme.frag has settled on it: its overall colour and its vivid
    // accent, the two cells that pass keeps for the sky. Until the first run has stored
    // anything the alpha is 0, and the sky is left neutral.
    vec4 meanC = texture2D(themenow, vec2(2.5 / 6.0, 0.5));
    vec4 accentC = texture2D(themenow, vec2(3.5 / 6.0, 0.5));
    // (Alpha is a flag here: 1 once the theme pass has stored a shown theme at all.)
    vec3 accent = accentC.a > 0.001 ? accentC.rgb : vec3(0.5);
    float lum = meanC.a > 0.001 ? dot(meanC.rgb, LUMA) : 0.30;

    vec3 sky = renderSky(skyRay(uv), accent, lum);

    // 8-bit output and a smooth gradient is a recipe for banding; a half-step of noise
    // breaks the contours up without being visible as noise.
    sky += (ign(gl_FragCoord.xy) - 0.5) * (1.5 / 255.0);

    gl_FragColor = vec4(mix(base.rgb, clamp(sky, 0.0, 1.0), clamp(w, 0.0, 1.0)), base.a);
}
