#version 120
// Bloom pass 3: spread down the screen.
#include "lib/color.glsl"
#include "lib/bloom.glsl"

void main ()
{
    gl_FragColor = vec4(bloomBlur(colortex5, gl_TexCoord[0].st, vec2(0.0, 1.0), BLOOM_SCALE), 1.0);
}
