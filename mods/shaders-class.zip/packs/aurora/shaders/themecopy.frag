#version 120
//
// Keeps this frame's theme for the next frame to average into. See theme.frag.
//
void main ()
{
    gl_FragColor = texture2D(themenow, gl_TexCoord[0].st);
}
