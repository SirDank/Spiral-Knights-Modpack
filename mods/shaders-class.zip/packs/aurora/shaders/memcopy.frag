#version 120
//
// Keeps this frame's memory for the next frame. See mem.frag.
//
void main ()
{
    gl_FragColor = texture2D(memnow, gl_TexCoord[0].st);
}
