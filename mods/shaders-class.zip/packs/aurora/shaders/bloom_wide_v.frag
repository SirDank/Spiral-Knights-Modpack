#version 120
// Wide bloom, down - and the point where the two scales are combined.
//
// Summing here rather than in the composite is not a stylistic choice. Fixed-function
// texture units cap at four, and the composite already needs scene colour, the shade
// buffer and depth; a fifth sampler overflows Renderer.setArrayState and takes the frame
// loop down with an ArrayIndexOutOfBoundsException. Both scales are weighted here and
// arrive as a single buffer.
#include "lib/color.glsl"
#include "lib/bloom.glsl"

void main ()
{
    vec2 uv = gl_TexCoord[0].st;
    vec3 wide  = bloomBlur(colortex9, uv, vec2(0.0, 1.0), BLOOM_WIDE_SCALE);
    vec3 tight = texture2D(colortex6, uv).rgb;
    gl_FragColor = vec4(tight * BLOOM_STRENGTH + wide * BLOOM_WIDE_STRENGTH, 1.0);
}
