#version 120
//
// Memory pass: what has this session seen?
//
// Twelve slots of four cells each - the fingerprint a place had at the end of its warm-up
// (mean and accent), and the final answer that was captured for it - kept in a small buffer
// that is read back and rewritten every frame, because that is all the memory a render
// target is. theme.frag searches it when a new place's warm-up ends; this pass is the only
// thing that writes it.
//
// A slot is written when a capture has FINISHED. One that was recognised is already in
// memory, so it is not written again. Which slot is a hash of the fingerprint, so the same
// kind of place lands on the same slot and replaces its older self rather than filling the
// memory with near-duplicates; the price is that two unlike places can collide and the
// newer wins, which costs a recapture and nothing worse.
//
// Reads: themenow (this frame's theme, six cells), memprev (the memory so far).
//
#define TN(r) texture2D(themenow, vec2((float(r) + 0.5) / 6.0, 0.5))

void main ()
{
    float cell = floor(gl_TexCoord[0].s * 48.0);
    float slot = floor(cell / 4.0);
    float k = cell - slot * 4.0;

    vec4 old = texture2D(memprev, vec2((cell + 0.5) / 48.0, 0.5));

#if SKY_THEME_LOCK && SKY_THEME_MEMORY
    vec4 cm = TN(0);
    vec4 ca = TN(1);
    vec4 gm = TN(4);
    vec4 ga = TN(5);

    float window = float(SKY_THEME_WARMUP) + float(SKY_THEME_FRAMES);
    bool finished = floor(ca.a * 255.0 + 0.5) >= window && gm.a > 0.5 && ga.a < 0.5;

    float target = floor(fract(sin(dot(gm.rgb * 255.0 + ga.rgb * 131.0, vec3(12.9898, 78.233, 37.719))) * 43758.5453) * 12.0);

    if (finished && abs(slot - target) < 0.5) {
        vec3 v = k < 0.5 ? gm.rgb : (k < 1.5 ? ga.rgb : (k < 2.5 ? cm.rgb : ca.rgb));
        gl_FragColor = vec4(v, 1.0);
        return;
    }
#endif
    gl_FragColor = old;
}
