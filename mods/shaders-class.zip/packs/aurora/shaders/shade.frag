#version 120
//
// Pass 1 of 7: indirect light, occlusion and contact shadows.
//
//   rgb = bounced light arriving at this pixel, tinted by whatever it bounced off
//   a   = direct visibility: ambient occlusion and sun shadow, combined
//
// Occlusion and shadow are both plain multiplicative darkening of the surface, so they
// collapse into one channel without losing anything - which is what frees rgb for the
// bounce. Keeping them apart would have cost a second buffer and a second blur chain.
//
// All three terms are sampled stochastically and are noisy here by design; the two blur
// passes that follow resolve them.
//
#include "lib/view.glsl"

/**
 * One spiral of samples around the pixel, used for all three terms at once.
 *
 * Each sample is a short ray: step away from this surface, find where the scene actually
 * is in that direction, and ask what it means. A surface close by and facing us occludes
 * (less ambient light reaches here) and also bounces its colour onto us. It is the same
 * query answering both questions, so they share the loop - the sampling is by far the
 * expensive part and doing it twice would double the cost of the pass for nothing.
 */
void gather (vec2 uv, vec3 p, vec3 n, float rotation, out float ao, out vec3 bounce)
{
    float ca = cos(rotation), sa = sin(rotation);
    float occlusion = 0.0;
    vec3 gathered = vec3(0.0);
    float gatheredWeight = 0.0;
    bounce = vec3(0.0);

    for (int i = 0; i < AO_SAMPLES; i++) {
        float t = (float(i) + 0.5) / float(AO_SAMPLES);
        float a = t * 6.2831853 * 3.0;
        vec2 dir = vec2(cos(a), sin(a));
        dir = vec2(dir.x * ca - dir.y * sa, dir.x * sa + dir.y * ca);

        vec3 proj = project(p + vec3(dir * sqrt(t) * GI_RADIUS, 0.0));
        if (!onScreen(proj.xy)) continue;

        vec3 delta = scenePosition(proj.xy) - p;
        float dist = length(delta);
        if (dist < 0.0001 || dist > GI_RADIUS * 2.0) continue;

        vec3 toSample = delta / dist;
        float facing = dot(toSample, n);
        if (facing <= 0.0) continue;               // behind this surface; contributes nothing

        float falloff = GI_RADIUS / (GI_RADIUS + dist);
        occlusion += max(0.0, facing - AO_BIAS) * falloff;

        // The bounce: that surface's colour, arriving here. Weighted the same way the
        // occlusion is, because it is the same solid angle - light this pixel loses to an
        // occluder is exactly the light that occluder can send back.
        float w = facing * falloff;
        gathered += texture2D(colortex0, proj.xy).rgb * w;
        gatheredWeight += w;
    }

    // How enclosed this pixel is, before AO_STRENGTH is applied to it.
    float enclosure = clamp((occlusion / float(AO_SAMPLES)) * 2.0, 0.0, 1.0);
    ao = clamp(1.0 - enclosure * AO_STRENGTH, 0.0, 1.0);

    // Normalise the bounce by the weight actually gathered, not by the sample count.
    // Most samples contribute nothing - they land off screen, too far away, or behind this
    // surface - so dividing by AO_SAMPLES scaled the result down by however many missed,
    // which made the whole term vanish into rounding. What the average wants to be is "the
    // colour of the surroundings"; how MUCH of it arrives is the enclosure term, applied
    // separately. Those are two different questions and dividing by the count conflated them.
    vec3 surroundings = gatheredWeight > 0.0001 ? gathered / gatheredWeight : vec3(0.0);
    bounce = surroundings * enclosure;
}

/**
 * Contact shadow: march toward the sun and accumulate what blocks the way.
 *
 * Partial occlusion rather than a first-hit test. A binary test makes every shadow edge a
 * hard step between lit and unlit, and blurring that gives a blurred hard step, not a
 * gradient.
 */
float sunlight (vec3 p, vec3 n, vec3 lightDir, float jitter)
{
    float facing = dot(n, lightDir);
    if (facing <= 0.0) return 0.0;              // facing away from the sun; already dark

    vec3 origin = p + n * SHADOW_BIAS;
    vec3 stride = lightDir * (SHADOW_LENGTH / float(SHADOW_STEPS));

    float blocked = 0.0;
    for (int i = 1; i <= SHADOW_STEPS; i++) {
        vec3 samplePos = origin + stride * (float(i) + jitter);
        vec3 proj = project(samplePos);
        if (!onScreen(proj.xy)) break;

        float diff = scenePosition(proj.xy).z - samplePos.z;
        if (diff > SHADOW_BIAS) {
            // How confident we are that this is a real occluder rather than an unrelated
            // surface the ray happens to pass behind. A hard `diff < THICKNESS` cut-off
            // fails badly on anything thicker than the threshold: a knight is several units
            // deep in view space, so every sample except the one grazing its silhouette was
            // rejected and the shadow came out as an outline with nothing inside it.
            // Fading instead means thickness controls how far behind a blocker the shadow
            // persists, rather than switching it off entirely.
            float solid = 1.0 - smoothstep(SHADOW_THICKNESS, SHADOW_THICKNESS * 3.0, diff);
            blocked += solid * (1.0 - float(i) / float(SHADOW_STEPS));   // nearer hits read as contact
        }
    }
    // Fade the SHADOW near the terminator, not the visibility. Multiplying the returned
    // visibility by the facing term was the same mistake in a second place: it darkened
    // surfaces the sun merely grazes, whether or not anything stood in the way.
    float shadow = blocked * (2.0 / float(SHADOW_STEPS));
    shadow *= smoothstep(0.0, 0.25, facing);
    return clamp(1.0 - shadow, 0.0, 1.0);
}

void main ()
{
    vec2 uv = gl_TexCoord[0].st;
    float depth = depthAt(uv);

    // Sky: fully lit, no bounce. Matching the far plane exactly keeps the blur from
    // dragging the horizon's values inward over the scene.
    if (depth >= 0.9999) { gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0); return; }

    vec3 p = viewPosition(uv, depth);

    vec3 n;
    float confidence;
    surfaceInfo(uv, p, n, confidence);

    float noise = ign(gl_FragCoord.xy);

    float ao = 1.0;
    vec3 bounce = vec3(0.0);
#if GI || AO
    gather(uv, p, n, noise * 6.2831853, ao, bounce);
#endif
#if !AO
    ao = 1.0;
#endif
#if !GI
    bounce = vec3(0.0);
#endif

    float sun = 1.0;
#if SHADOWS
    vec3 lightDir = normalize((uView * vec4(SUN_X, SUN_Y, SUN_Z, 0.0)).xyz);
    sun = sunlight(p, n, lightDir, noise);
#endif

    // Fade everything out across a silhouette. The pixels there have neighbours belonging
    // to a different object, so their gather is guesswork - and it is guesswork that lands
    // dark, which is what drew a rim around every character.
    float visibility = ao * mix(1.0 - SHADOW_STRENGTH, 1.0, sun);
    visibility = mix(1.0, visibility, confidence);
    bounce *= confidence;

    gl_FragColor = vec4(bounce, visibility);
}
