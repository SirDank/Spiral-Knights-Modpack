By default I've set the Leviathan blade as the Lionheart reskin for this mod but if you want to instead replace the combuster, glacius, or voltedge move the respective model_brandish-(ele)-r3.dat into the calibur folder and delete the model_adv.dat if you want to remove the Leviathan reskin.
fir = Combuster
fre = Glacius
sho = Voltedge