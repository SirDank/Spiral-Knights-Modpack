I've made the closed version of the helmet the default but if you want to use the open version of the helmet instead follow these steps below.
1. in the nose folder delete model_cobalt-r4.dat
2. in the honour guard folder copy model_cobalt-r4-open.dat
3. paste model_cobalt-r4-open.dat into the nose folder
3. rename model_cobalt-r4-open.dat to model_cobalt-r4.dat

If you want to undo this change
1. in the nose folder delete model_cobalt-r4.dat
2. in the honour guard folder copy model_cobalt-r4-closed.dat
3. paste model_cobalt-r4-closed.dat into the nose folder
3. rename model_cobalt-r4-closed.dat to model_cobalt-r4.dat