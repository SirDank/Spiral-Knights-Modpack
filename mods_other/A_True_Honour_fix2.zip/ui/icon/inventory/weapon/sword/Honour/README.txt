I've made the leviathan blade the default reskin but if you want to use a brandish instead follow these steps below.
1. in the honour folder copy the desired icon(s) of your choice (combuster, glacius, voltedge, or leviathan_blade)
2. in the sword folder delete any current replacements you don't want
3. paste the copied icon(s) into the sword folder